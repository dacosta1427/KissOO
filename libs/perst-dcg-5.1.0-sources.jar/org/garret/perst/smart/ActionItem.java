package org.garret.perst.smart;

/**
 * Represents a specific action to take for index optimization.
 */
public class ActionItem {
    
    public enum ActionType {
        ADD_INDEX("Add index"),
        CHANGE_INDEX("Change index type"),
        ADD_LUCENE("Add full-text search"),
        REMOVE_INDEX("Remove unnecessary index"),
        REVIEW("Review manually");
        
        private final String description;
        ActionType(String description) { this.description = description; }
        public String getDescription() { return description; }
    }
    
    private final String fieldName;
    private final ActionType action;
    private final IndexType indexType;
    private final String reason;
    private final String codeSnippet;
    private final Confidence confidence;
    private final ImpactEstimate impact;
    
    public ActionItem(String fieldName, ActionType action, IndexType indexType,
            String reason, String codeSnippet, Confidence confidence, ImpactEstimate impact) {
        this.fieldName = fieldName;
        this.action = action;
        this.indexType = indexType;
        this.reason = reason;
        this.codeSnippet = codeSnippet;
        this.confidence = confidence;
        this.impact = impact;
    }
    
    // Getters
    public String getFieldName() { return fieldName; }
    public ActionType getAction() { return action; }
    public IndexType getIndexType() { return indexType; }
    public String getReason() { return reason; }
    public String getCodeSnippet() { return codeSnippet; }
    public Confidence getConfidence() { return confidence; }
    public ImpactEstimate getImpact() { return impact; }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[").append(confidence.name()).append("] ");
        sb.append(action.getDescription()).append(" on '").append(fieldName).append("' → ");
        sb.append(indexType.name());
        if (impact != null) {
            sb.append(" (").append(impact.getAffectedQueries()).append(" queries, ~")
              .append(String.format("%.1fx", impact.getEstimatedSpeedup())).append(" faster)");
        }
        sb.append("\n    Reason: ").append(reason);
        return sb.toString();
    }
}
