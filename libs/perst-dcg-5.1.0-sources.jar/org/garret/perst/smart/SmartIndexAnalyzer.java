package org.garret.perst.smart;

import org.garret.perst.continuous.CVersion;
import org.garret.perst.continuous.FullTextSearchable;
import org.garret.perst.Indexable;
import org.garret.perst.continuous.CDatabase;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;

/**
 * Analyzes CVersion class fields and recommends optimal index types.
 * 
 * Performs static analysis of:
 * - Field types (boolean, enum, String, numeric, etc.)
 * - String lengths (for BTree vs Lucene decision)
 * - Existing annotations (@Indexable, @FullTextSearchable)
 * - Cardinality estimation for String fields
 */
public class SmartIndexAnalyzer {
    
    // Thresholds from SMART_INDEX_PLAN.md
    private static final int LOW_CARDINALITY_THRESHOLD = 10;
    private static final int MEDIUM_TEXT_THRESHOLD = 200;
    private static final int LONG_TEXT_THRESHOLD = 500;
    private static final int BTREE_MAX_STRING = 2042;
    
    private final CDatabase cdb;
    
    public SmartIndexAnalyzer(CDatabase cdb) {
        this.cdb = cdb;
    }
    
    /**
     * Analyze a CVersion class and return field analyses.
     */
    public List<FieldAnalysis> analyze(Class<? extends CVersion> clazz) {
        List<FieldAnalysis> analyses = new ArrayList<>();
        
        for (Field field : getPersistentFields(clazz)) {
            FieldAnalysis analysis = analyzeField(field);
            if (analysis != null) {
                analyses.add(analysis);
            }
        }
        
        return analyses;
    }
    
    /**
     * Analyze a single field and recommend index type.
     */
    public FieldAnalysis analyzeField(Field field) {
        FieldAnalysis.Builder builder = new FieldAnalysis.Builder()
            .field(field)
            .fieldName(field.getName())
            .fieldType(field.getType());
        
        Class<?> type = field.getType();
        
        // Check existing annotations
        IndexType currentIndex = detectCurrentIndex(field);
        builder.currentIndex(currentIndex);
        
        // Detect field type and recommend index
        FieldType detectedType = detectFieldType(type, field);
        builder.detectedType(detectedType);
        
        IndexType recommended = recommendIndex(type, field, detectedType);
        builder.recommendedIndex(recommended);
        
        // Set confidence and reason
        setConfidenceAndReason(builder, type, field, detectedType, recommended, currentIndex);
        
        return builder.build();
    }
    
    /**
     * Detect the current index type from annotations.
     */
    private IndexType detectCurrentIndex(Field field) {
        if (field.isAnnotationPresent(Indexable.class)) {
            Indexable ann = field.getAnnotation(Indexable.class);
            if (ann.thick()) {
                return IndexType.THICK;
            }
            if (ann.regex()) {
                return IndexType.REGEX;
            }
            return IndexType.BTREE;
        }
        if (field.isAnnotationPresent(FullTextSearchable.class)) {
            return IndexType.LUCENE;
        }
        return null; // Not indexed
    }
    
    /**
     * Detect the field type classification.
     */
    private FieldType detectFieldType(Class<?> type, Field field) {
        // Boolean
        if (type == boolean.class || type == Boolean.class) {
            return FieldType.BOOLEAN;
        }
        
        // Enum
        if (type.isEnum()) {
            return FieldType.ENUM;
        }
        
        // Numeric
        if (isNumeric(type)) {
            return FieldType.NUMERIC;
        }
        
        // Date
        if (type == java.util.Date.class || type == java.time.temporal.Temporal.class ||
            type.getName().startsWith("java.time.")) {
            return FieldType.DATE;
        }
        
        // String - classify by length
        if (type == String.class) {
            int maxLength = estimateMaxLength(field);
            if (maxLength > BTREE_MAX_STRING) {
                return FieldType.VERY_LONG_STRING;
            } else if (maxLength > LONG_TEXT_THRESHOLD) {
                return FieldType.LONG_STRING;
            } else if (maxLength > MEDIUM_TEXT_THRESHOLD) {
                return FieldType.MEDIUM_STRING;
            } else {
                return FieldType.SHORT_STRING;
            }
        }
        
        return FieldType.UNKNOWN;
    }
    
    /**
     * Recommend index type based on field characteristics.
     */
    private IndexType recommendIndex(Class<?> type, Field field, FieldType fieldType) {
        
        // Boolean → ThickIndex
        if (fieldType == FieldType.BOOLEAN) {
            return IndexType.THICK;
        }
        
        // Enum → ThickIndex (low cardinality)
        if (fieldType == FieldType.ENUM) {
            return IndexType.THICK;
        }
        
        // String handling
        if (type == String.class) {
            // Check for @Indexable(regex=true) - user already decided
            if (field.isAnnotationPresent(Indexable.class) && 
                field.getAnnotation(Indexable.class).regex()) {
                return IndexType.REGEX;
            }
            
            // Check for @FullTextSearchable
            if (field.isAnnotationPresent(FullTextSearchable.class)) {
                return IndexType.LUCENE;
            }
            
            // Length-based recommendation
            int maxLength = estimateMaxLength(field);
            if (maxLength > BTREE_MAX_STRING) {
                return IndexType.LUCENE;  // Must use Lucene
            }
            if (maxLength > LONG_TEXT_THRESHOLD) {
                // Long text - recommend Lucene but BTree still works
                return IndexType.LUCENE;
            }
            
            // Short/Medium strings → BTree by default
            return IndexType.BTREE;
        }
        
        // Numeric, Date → BTree
        if (isNumeric(type) || fieldType == FieldType.DATE) {
            return IndexType.BTREE;
        }
        
        // Default: no specific recommendation
        return IndexType.NONE;
    }
    
    /**
     * Set confidence level and reason for the recommendation.
     */
    private void setConfidenceAndReason(FieldAnalysis.Builder builder, 
            Class<?> type, Field field, FieldType detectedType, 
            IndexType recommended, IndexType current) {
        
        // No change needed
        if (current == recommended || recommended == IndexType.NONE) {
            builder.confidence(Confidence.HIGH);
            builder.reason("Already indexed correctly or no index needed");
            return;
        }
        
        // High confidence cases
        if (detectedType == FieldType.BOOLEAN || detectedType == FieldType.ENUM) {
            builder.confidence(Confidence.HIGH);
            builder.reason("Low cardinality field (" + detectedType + ") → ThickIndex");
            builder.estimatedCardinality(estimateCardinality(field));
            return;
        }
        
        if (detectedType == FieldType.VERY_LONG_STRING) {
            builder.confidence(Confidence.HIGH);
            builder.reason("String exceeds BTree limit (2042 chars) → Lucene required");
            return;
        }
        
        if (current == null) {
            builder.confidence(Confidence.MEDIUM);
            builder.reason("Unindexed field that may benefit from " + recommended.name());
            return;
        }
        
        builder.confidence(Confidence.LOW);
        builder.reason("Consider " + recommended.name() + " instead of " + current.name());
    }
    
    /**
     * Get persistent (non-static, non-transient) fields from class.
     */
    private List<Field> getPersistentFields(Class<?> clazz) {
        List<Field> fields = new ArrayList<>();
        for (Field field : clazz.getDeclaredFields()) {
            int mods = field.getModifiers();
            if (!Modifier.isStatic(mods) && !Modifier.isTransient(mods)) {
                field.setAccessible(true);
                fields.add(field);
            }
        }
        return fields;
    }
    
    /**
     * Check if a type is numeric.
     */
    private boolean isNumeric(Class<?> type) {
        return type == int.class || type == Integer.class ||
               type == long.class || type == Long.class ||
               type == double.class || type == Double.class ||
               type == float.class || type == Float.class ||
               type == short.class || type == Short.class ||
               type == byte.class || type == Byte.class;
    }
    
    /**
     * Estimate maximum string length for a field.
     * Uses default heuristic of 100 characters.
     */
    private int estimateMaxLength(Field field) {
        // Default heuristic - can be enhanced with field name heuristics
        // e.g., "description", "content", "bio" tend to be longer
        String name = field.getName().toLowerCase();
        if (name.contains("description") || name.contains("content") || 
            name.contains("bio") || name.contains("text") || 
            name.contains("body") || name.contains("comment")) {
            return 500;  // Likely longer text
        }
        if (name.contains("name") || name.contains("title") || 
            name.contains("email") || name.contains("code")) {
            return 100;  // Likely shorter strings
        }
        return 100;  // Default
    }
    
    /**
     * Estimate cardinality for a field.
     * For enums, returns enum constant count.
     * For booleans, returns 2.
     * For others, returns unknown (-1).
     */
    private int estimateCardinality(Field field) {
        Class<?> type = field.getType();
        
        if (type == boolean.class || type == Boolean.class) {
            return 2;
        }
        
        if (type.isEnum()) {
            return type.getEnumConstants().length;
        }
        
        return -1; // Unknown
    }
}
