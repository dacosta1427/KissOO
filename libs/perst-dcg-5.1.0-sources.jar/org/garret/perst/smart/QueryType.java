package org.garret.perst.smart;

/**
 * Types of queries for logging.
 */
public enum QueryType {
    EXACT("Exact match query"),
    RANGE("Range query (min/max)"),
    PREFIX("Prefix query"),
    FULLTEXT("Full-text search"),
    PATTERN("Pattern/regex query"),
    ALL_RECORDS("Get all records");
    
    private final String description;
    
    QueryType(String description) {
        this.description = description;
    }
    
    public String getDescription() { return description; }
}
