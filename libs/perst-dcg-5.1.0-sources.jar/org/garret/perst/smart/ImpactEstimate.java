package org.garret.perst.smart;

/**
 * Estimated impact of an index optimization.
 */
public class ImpactEstimate {
    
    private final int affectedQueries;
    private final double estimatedSpeedup;
    private final double indexSizeMB;
    
    public ImpactEstimate(int affectedQueries, double estimatedSpeedup, double indexSizeMB) {
        this.affectedQueries = affectedQueries;
        this.estimatedSpeedup = estimatedSpeedup;
        this.indexSizeMB = indexSizeMB;
    }
    
    public ImpactEstimate(int affectedQueries, double estimatedSpeedup) {
        this(affectedQueries, estimatedSpeedup, 0);
    }
    
    public int getAffectedQueries() { return affectedQueries; }
    public double getEstimatedSpeedup() { return estimatedSpeedup; }
    public double getIndexSizeMB() { return indexSizeMB; }
    
    /**
     * Get impact level based on speedup.
     */
    public String getImpactLevel() {
        if (estimatedSpeedup >= 10) return "HIGH";
        if (estimatedSpeedup >= 3) return "MEDIUM";
        return "LOW";
    }
    
    @Override
    public String toString() {
        return String.format("Impact[%d queries, %.1fx speedup, %.1fMB index]",
            affectedQueries, estimatedSpeedup, indexSizeMB);
    }
}
