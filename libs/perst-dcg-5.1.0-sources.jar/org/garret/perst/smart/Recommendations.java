package org.garret.perst.smart;

import org.garret.perst.continuous.CVersion;

import java.util.ArrayList;
import java.util.List;

/**
 * Complete recommendation output for a CVersion class.
 */
public class Recommendations {
    
    private final Class<? extends CVersion> targetClass;
    private final List<FieldAnalysis> fieldAnalyses;
    private final List<QueryOptimization> queryInsights;
    private final List<ActionItem> actions;
    
    public Recommendations(Class<? extends CVersion> targetClass) {
        this.targetClass = targetClass;
        this.fieldAnalyses = new ArrayList<>();
        this.queryInsights = new ArrayList<>();
        this.actions = new ArrayList<>();
    }
    
    // Adders
    public void addFieldAnalysis(FieldAnalysis analysis) { fieldAnalyses.add(analysis); }
    public void addQueryInsight(QueryOptimization insight) { queryInsights.add(insight); }
    public void addAction(ActionItem action) { actions.add(action); }
    
    // Getters
    public Class<? extends CVersion> getTargetClass() { return targetClass; }
    public List<FieldAnalysis> getFieldAnalyses() { return fieldAnalyses; }
    public List<QueryOptimization> getQueryInsights() { return queryInsights; }
    public List<ActionItem> getActions() { return actions; }
    
    /**
     * Get high priority actions.
     */
    public List<ActionItem> getHighPriority() {
        return actions.stream()
            .filter(a -> a.getConfidence() == Confidence.HIGH)
            .collect(java.util.stream.Collectors.toList());
    }
    
    /**
     * Get medium priority actions.
     */
    public List<ActionItem> getMediumPriority() {
        return actions.stream()
            .filter(a -> a.getConfidence() == Confidence.MEDIUM)
            .collect(java.util.stream.Collectors.toList());
    }
    
    /**
     * Get low priority actions.
     */
    public List<ActionItem> getLowPriority() {
        return actions.stream()
            .filter(a -> a.getConfidence() == Confidence.LOW)
            .collect(java.util.stream.Collectors.toList());
    }
    
    /**
     * Check if any optimizations are recommended.
     */
    public boolean hasRecommendations() {
        return !actions.isEmpty() || !queryInsights.isEmpty();
    }
    
    /**
     * Get a human-readable summary.
     */
    public String getSummary() {
        StringBuilder sb = new StringBuilder();
        sb.append("Analysis for ").append(targetClass.getSimpleName()).append(":\n");
        sb.append("  Fields analyzed: ").append(fieldAnalyses.size()).append("\n");
        
        long indexedCount = fieldAnalyses.stream()
            .filter(a -> a.getCurrentIndex() != null)
            .count();
        sb.append("  Indexed fields: ").append(indexedCount).append("\n");
        sb.append("  Unindexed fields: ").append(fieldAnalyses.size() - indexedCount).append("\n");
        
        if (hasRecommendations()) {
            sb.append("\nRecommendations:\n");
            for (ActionItem action : actions) {
                sb.append("  ").append(action).append("\n");
            }
        } else {
            sb.append("\nNo optimizations needed.\n");
        }
        
        return sb.toString();
    }
    
    @Override
    public String toString() {
        return getSummary();
    }
}
