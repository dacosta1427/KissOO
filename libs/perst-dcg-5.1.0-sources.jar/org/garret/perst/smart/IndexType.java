package org.garret.perst.smart;

/**
 * Recommended index types for smart auto-detection.
 */
public enum IndexType {
    BTREE("BTree index - exact match, range, prefix", "@Indexable"),
    THICK("ThickIndex - low cardinality fields", "@Indexable(thick=true)"),
    LUCENE("Full-text search - text fields, ranking", "@FullTextSearchable"),
    REGEX("RegexIndex - pattern matching", "@Indexable(regex=true)"),
    SPATIAL("SpatialIndexR2 - 2D coordinates", "Manual spatial index"),
    MULTIDIMENSIONAL("Multidimensional - multi-field ranges", "Manual KDTree"),
    NONE("No index needed", "");
    
    private final String description;
    private final String codeSnippet;
    
    IndexType(String description, String codeSnippet) {
        this.description = description;
        this.codeSnippet = codeSnippet;
    }
    
    public String getDescription() { return description; }
    public String getCodeSnippet() { return codeSnippet; }
}
