package org.garret.perst.smart;

import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tracks query patterns and performance for index optimization.
 * 
 * Thread-safe implementation for production use.
 * Tracks per-field query statistics to identify optimization opportunities.
 */
public class QueryLogger {
    
    private static final long DEFAULT_SLOW_THRESHOLD_MS = 100;
    private static final int MIN_QUERIES_FOR_RECOMMENDATION = 50;
    private static final double MIN_SPEEDUP_FOR_RECOMMENDATION = 2.0;
    
    private volatile boolean enabled = true;
    private volatile long slowThresholdMs = DEFAULT_SLOW_THRESHOLD_MS;
    private final Map<String, QueryStats> stats = new ConcurrentHashMap<>();
    
    /**
     * Record a query execution.
     * 
     * @param fieldName The field being queried
     * @param type The type of query
     * @param durationMs Query execution time in milliseconds
     * @param hasIndex Whether the field has an index
     */
    public void record(String fieldName, QueryType type, long durationMs, boolean hasIndex) {
        if (!enabled) return;
        
        stats.computeIfAbsent(fieldName, QueryStats::new)
             .record(type, durationMs, hasIndex);
    }
    
    /**
     * Record a query execution (convenience method - assumes index unknown).
     */
    public void record(String fieldName, QueryType type, long durationMs) {
        record(fieldName, type, durationMs, true); // Assume indexed, caller can specify
    }
    
    /**
     * Get statistics for a specific field.
     */
    public QueryStats getStats(String fieldName) {
        return stats.get(fieldName);
    }
    
    /**
     * Get all field statistics.
     */
    public Collection<QueryStats> getAllStats() {
        return Collections.unmodifiableCollection(stats.values());
    }
    
    /**
     * Get fields that need index optimization.
     */
    public java.util.List<QueryOptimization> getOptimizations() {
        java.util.List<QueryOptimization> optimizations = new java.util.ArrayList<>();
        
        for (QueryStats stat : stats.values()) {
            QueryOptimization opt = analyzeForOptimization(stat);
            if (opt != null) {
                optimizations.add(opt);
            }
        }
        
        // Sort by impact (queries × speedup)
        optimizations.sort((a, b) -> 
            Integer.compare(b.getAffectedQueries(), a.getAffectedQueries()));
        
        return optimizations;
    }
    
    /**
     * Analyze a field's stats for optimization opportunities.
     */
    private QueryOptimization analyzeForOptimization(QueryStats stat) {
        // Need minimum queries to make recommendation
        if (stat.getTotalQueries() < MIN_QUERIES_FOR_RECOMMENDATION) {
            return null;
        }
        
        String field = stat.getFieldName();
        
        // No index detected + slow queries → add index
        if (stat.getNoIndexQueryCount() > 100 && stat.isSlow()) {
            QueryType dominant = stat.getDominantQueryType();
            IndexType recommended = getIndexForQueryType(dominant);
            
            return new QueryOptimization(
                field,
                recommended,
                String.format("Field has %d unindexed queries averaging %.1fms",
                    stat.getNoIndexQueryCount(), stat.getAverageTimeMs()),
                (int) Math.min(stat.getNoIndexQueryCount(), Integer.MAX_VALUE),
                Confidence.HIGH
            );
        }
        
        // Has index but slow pattern queries → add RegexIndex
        if (stat.hasPatternQueries() && stat.getPatternQueryCount() > 50 && stat.isSlow()) {
            return new QueryOptimization(
                field,
                IndexType.REGEX,
                String.format("Field has %d pattern queries averaging %.1fms - RegexIndex recommended",
                    stat.getPatternQueryCount(), stat.getAverageTimeMs()),
                (int) stat.getPatternQueryCount(),
                Confidence.HIGH
            );
        }
        
        // Has BTree but full-text queries → add Lucene
        if (stat.getFullTextQueryCount() > 100) {
            return new QueryOptimization(
                field,
                IndexType.LUCENE,
                String.format("Field has %d full-text queries - @FullTextSearchable recommended",
                    stat.getFullTextQueryCount()),
                (int) stat.getFullTextQueryCount(),
                Confidence.MEDIUM
            );
        }
        
        return null;
    }
    
    /**
     * Map query type to recommended index.
     */
    private IndexType getIndexForQueryType(QueryType type) {
        if (type == null) return IndexType.BTREE;
        
        switch (type) {
            case EXACT: return IndexType.BTREE;
            case RANGE: return IndexType.BTREE;
            case PREFIX: return IndexType.BTREE;
            case PATTERN: return IndexType.REGEX;
            case FULLTEXT: return IndexType.LUCENE;
            default: return IndexType.BTREE;
        }
    }
    
    // Configuration
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public boolean isEnabled() { return enabled; }
    
    public void setSlowThresholdMs(long ms) { this.slowThresholdMs = ms; }
    public long getSlowThresholdMs() { return slowThresholdMs; }
    
    public void reset() { stats.clear(); }
    
    public int getTrackedFieldCount() { return stats.size(); }
    
    public long getTotalQueries() {
        return stats.values().stream()
            .mapToLong(QueryStats::getTotalQueries)
            .sum();
    }
}
