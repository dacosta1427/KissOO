package org.garret.perst.smart;

/**
 * Classification of field types for index recommendation.
 */
public enum FieldType {
    BOOLEAN,            // boolean/Boolean - ThickIndex (2 values)
    ENUM,               // Any enum - ThickIndex (low cardinality)
    NUMERIC,            // int, long, float, double - BTree
    DATE,               // Date, Instant - BTree for range queries
    SHORT_STRING,       // String ≤200 chars - BTree
    MEDIUM_STRING,      // String 200-500 chars - Lucene + BTree
    LONG_STRING,        // String >500 chars - Lucene
    VERY_LONG_STRING,   // String >2042 chars - Lucene only (BTree limit)
    SPATIAL,            // Has lat/lon - SpatialIndexR2
    UNKNOWN             // Cannot determine
}
