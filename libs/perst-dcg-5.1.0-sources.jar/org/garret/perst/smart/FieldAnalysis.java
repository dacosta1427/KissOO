package org.garret.perst.smart;

import java.lang.reflect.Field;

/**
 * Analysis result for a single field in a CVersion class.
 */
public class FieldAnalysis {
    
    private final Field field;
    private final String fieldName;
    private final Class<?> fieldType;
    private final FieldType detectedType;
    private final IndexType currentIndex;
    private final IndexType recommendedIndex;
    private final Confidence confidence;
    private final String reason;
    private final int estimatedCardinality;
    private final int maxLength;
    private final boolean isAnnotationMismatch;
    
    private FieldAnalysis(Builder builder) {
        this.field = builder.field;
        this.fieldName = builder.fieldName;
        this.fieldType = builder.fieldType;
        this.detectedType = builder.detectedType;
        this.currentIndex = builder.currentIndex;
        this.recommendedIndex = builder.recommendedIndex;
        this.confidence = builder.confidence;
        this.reason = builder.reason;
        this.estimatedCardinality = builder.estimatedCardinality;
        this.maxLength = builder.maxLength;
        this.isAnnotationMismatch = builder.isAnnotationMismatch;
    }
    
    // Getters
    public Field getField() { return field; }
    public String getFieldName() { return fieldName; }
    public Class<?> getFieldType() { return fieldType; }
    public FieldType getDetectedType() { return detectedType; }
    public IndexType getCurrentIndex() { return currentIndex; }
    public IndexType getRecommendedIndex() { return recommendedIndex; }
    public Confidence getConfidence() { return confidence; }
    public String getReason() { return reason; }
    public int getEstimatedCardinality() { return estimatedCardinality; }
    public int getMaxLength() { return maxLength; }
    public boolean isAnnotationMismatch() { return isAnnotationMismatch; }
    
    /**
     * Check if this field needs optimization.
     */
    public boolean needsOptimization() {
        return recommendedIndex != null && recommendedIndex != currentIndex;
    }
    
    /**
     * Generate code snippet for the recommended index.
     */
    public String getCodeSnippet() {
        if (recommendedIndex == null || recommendedIndex == IndexType.NONE) {
            return "// No index needed for " + fieldName;
        }
        
        StringBuilder sb = new StringBuilder();
        sb.append(recommendedIndex.getCodeSnippet());
        
        // Add specific attributes based on index type
        switch (recommendedIndex) {
            case BTREE:
                if (estimatedCardinality < 10) {
                    sb.append("(thick = true)  // Low cardinality (~")
                      .append(estimatedCardinality).append(" values)");
                }
                break;
            case THICK:
                sb.append("  // ~").append(estimatedCardinality).append(" unique values");
                break;
            case LUCENE:
                if (maxLength > 2042) {
                    sb.append("  // Exceeds BTree limit (2042 chars)");
                }
                break;
            default:
                break;
        }
        
        sb.append("\nprivate ").append(fieldType.getSimpleName())
          .append(" ").append(fieldName).append(";");
        
        return sb.toString();
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Field '").append(fieldName).append("' (").append(fieldType.getSimpleName()).append("): ");
        
        if (currentIndex != null) {
            sb.append("Current=").append(currentIndex.name());
        } else {
            sb.append("Not indexed");
        }
        
        if (needsOptimization()) {
            sb.append(" → Recommended=").append(recommendedIndex.name())
              .append(" [").append(confidence.name()).append("]")
              .append(" - ").append(reason);
        } else if (currentIndex != null) {
            sb.append(" ✓ Optimal");
        }
        
        if (estimatedCardinality > 0) {
            sb.append(" (cardinality: ~").append(estimatedCardinality).append(")");
        }
        
        return sb.toString();
    }
    
    /**
     * Builder for FieldAnalysis.
     */
    public static class Builder {
        private Field field;
        private String fieldName;
        private Class<?> fieldType;
        private FieldType detectedType;
        private IndexType currentIndex;
        private IndexType recommendedIndex;
        private Confidence confidence;
        private String reason;
        private int estimatedCardinality;
        private int maxLength;
        private boolean isAnnotationMismatch;
        
        public Builder field(Field field) {
            this.field = field;
            this.fieldName = field.getName();
            this.fieldType = field.getType();
            return this;
        }
        
        public Builder fieldName(String name) {
            this.fieldName = name;
            return this;
        }
        
        public Builder fieldType(Class<?> type) {
            this.fieldType = type;
            return this;
        }
        
        public Builder detectedType(FieldType type) {
            this.detectedType = type;
            return this;
        }
        
        public Builder currentIndex(IndexType type) {
            this.currentIndex = type;
            return this;
        }
        
        public Builder recommendedIndex(IndexType type) {
            this.recommendedIndex = type;
            return this;
        }
        
        public Builder confidence(Confidence level) {
            this.confidence = level;
            return this;
        }
        
        public Builder reason(String reason) {
            this.reason = reason;
            return this;
        }
        
        public Builder estimatedCardinality(int count) {
            this.estimatedCardinality = count;
            return this;
        }
        
        public Builder maxLength(int length) {
            this.maxLength = length;
            return this;
        }
        
        public Builder annotationMismatch(boolean mismatch) {
            this.isAnnotationMismatch = mismatch;
            return this;
        }
        
        public FieldAnalysis build() {
            return new FieldAnalysis(this);
        }
    }
}
