package org.garret.perst.smart;

/**
 * Represents an index optimization recommendation based on query patterns.
 */
public class QueryOptimization {
    
    private final String fieldName;
    private final IndexType recommendedIndex;
    private final String reason;
    private final int affectedQueries;
    private final Confidence confidence;
    
    public QueryOptimization(String fieldName, IndexType recommendedIndex, 
            String reason, int affectedQueries, Confidence confidence) {
        this.fieldName = fieldName;
        this.recommendedIndex = recommendedIndex;
        this.reason = reason;
        this.affectedQueries = affectedQueries;
        this.confidence = confidence;
    }
    
    // Getters
    public String getFieldName() { return fieldName; }
    public IndexType getRecommendedIndex() { return recommendedIndex; }
    public String getReason() { return reason; }
    public int getAffectedQueries() { return affectedQueries; }
    public Confidence getConfidence() { return confidence; }
    
    /**
     * Get the code snippet for applying this optimization.
     */
    public String getCodeSnippet() {
        switch (recommendedIndex) {
            case BTREE:
                return "@Indexable\nprivate String " + fieldName + ";";
            case THICK:
                return "@Indexable(thick = true)\nprivate String " + fieldName + ";";
            case LUCENE:
                return "@FullTextSearchable\nprivate String " + fieldName + ";";
            case REGEX:
                return "@Indexable(regex = true)\nprivate String " + fieldName + ";";
            default:
                return "// No change needed";
        }
    }
    
    @Override
    public String toString() {
        return String.format("[%s] Field '%s': Add %s (%d queries affected) - %s",
            confidence.name(), fieldName, recommendedIndex.name(), affectedQueries, reason);
    }
}
