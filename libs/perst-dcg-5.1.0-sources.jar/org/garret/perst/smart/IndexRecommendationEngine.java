package org.garret.perst.smart;

import org.garret.perst.continuous.CDatabase;
import org.garret.perst.continuous.CVersion;

import java.util.ArrayList;
import java.util.List;

/**
 * Combines static and dynamic analysis to produce index recommendations.
 * 
 * The engine:
 * 1. Runs static analysis (SmartIndexAnalyzer) on field types
 * 2. Checks query logs (QueryLogger) for performance patterns
 * 3. Merges recommendations with conflict resolution
 * 4. Outputs prioritized action items
 */
public class IndexRecommendationEngine {
    
    private final SmartIndexAnalyzer analyzer;
    private final QueryLogger queryLogger;
    
    public IndexRecommendationEngine(CDatabase cdb) {
        this.analyzer = new SmartIndexAnalyzer(cdb);
        this.queryLogger = new QueryLogger();
    }
    
    /**
     * Analyze a CVersion class and return comprehensive recommendations.
     */
    public <T extends CVersion> Recommendations analyze(Class<T> clazz) {
        Recommendations recs = new Recommendations(clazz);
        
        // Step 1: Static analysis of all fields
        List<FieldAnalysis> staticAnalyses = analyzer.analyze(clazz);
        for (FieldAnalysis analysis : staticAnalyses) {
            recs.addFieldAnalysis(analysis);
            
            // Add action if optimization needed
            if (analysis.needsOptimization()) {
                ActionItem action = createActionFromAnalysis(analysis);
                recs.addAction(action);
            }
        }
        
        // Step 2: Dynamic analysis from query logs
        List<QueryOptimization> dynamicInsights = queryLogger.getOptimizations();
        for (QueryOptimization insight : dynamicInsights) {
            recs.addQueryInsight(insight);
            
            // Convert to action item
            ActionItem action = new ActionItem(
                insight.getFieldName(),
                ActionItem.ActionType.ADD_INDEX,
                insight.getRecommendedIndex(),
                insight.getReason(),
                insight.getCodeSnippet(),
                insight.getConfidence(),
                new ImpactEstimate(insight.getAffectedQueries(), 5.0)
            );
            recs.addAction(action);
        }
        
        // Step 3: Conflict resolution
        // If static and dynamic disagree, prefer dynamic (based on actual queries)
        resolveConflicts(recs);
        
        return recs;
    }
    
    /**
     * Create an action item from static analysis.
     */
    private ActionItem createActionFromAnalysis(FieldAnalysis analysis) {
        ActionItem.ActionType actionType;
        switch (analysis.getRecommendedIndex()) {
            case LUCENE:
                actionType = ActionItem.ActionType.ADD_LUCENE;
                break;
            case NONE:
                actionType = ActionItem.ActionType.REVIEW;
                break;
            default:
                actionType = ActionItem.ActionType.ADD_INDEX;
        }
        
        return new ActionItem(
            analysis.getFieldName(),
            actionType,
            analysis.getRecommendedIndex(),
            analysis.getReason(),
            analysis.getCodeSnippet(),
            analysis.getConfidence(),
            new ImpactEstimate(0, 0)  // No query data for static analysis
        );
    }
    
    /**
     * Resolve conflicts between static and dynamic recommendations.
     */
    private void resolveConflicts(Recommendations recs) {
        // Simple conflict resolution: 
        // If static says BTree but dynamic says REGEX (due to pattern queries),
        // keep REGEX recommendation since it's based on actual usage
        List<ActionItem> actions = recs.getActions();
        
        // Group by field name and resolve
        // (For now, we just add both - more sophisticated merging could be done)
    }
    
    /**
     * Get the query logger for recording queries.
     */
    public QueryLogger getQueryLogger() {
        return queryLogger;
    }
    
    /**
     * Get the smart analyzer.
     */
    public SmartIndexAnalyzer getAnalyzer() {
        return analyzer;
    }
}
