package org.garret.perst.smart;

import java.util.concurrent.atomic.AtomicLong;

/**
 * Statistics for a single field's query performance.
 */
public class QueryStats {
    
    private static final long SLOW_THRESHOLD_MS = 100;
    
    private final String fieldName;
    private final AtomicLong totalQueries = new AtomicLong();
    private final AtomicLong totalTimeMs = new AtomicLong();
    private final AtomicLong minTimeMs = new AtomicLong(Long.MAX_VALUE);
    private final AtomicLong maxTimeMs = new AtomicLong();
    private final AtomicLong exactMatchCount = new AtomicLong();
    private final AtomicLong rangeQueryCount = new AtomicLong();
    private final AtomicLong patternQueryCount = new AtomicLong();
    private final AtomicLong fullTextQueryCount = new AtomicLong();
    private final AtomicLong noIndexQueryCount = new AtomicLong();
    
    public QueryStats(String fieldName) {
        this.fieldName = fieldName;
    }
    
    public void record(QueryType type, long durationMs, boolean hasIndex) {
        totalQueries.incrementAndGet();
        totalTimeMs.addAndGet(durationMs);
        
        // Update min/max
        long currentMin;
        do {
            currentMin = minTimeMs.get();
        } while (durationMs < currentMin && !minTimeMs.compareAndSet(currentMin, durationMs));
        
        long currentMax;
        do {
            currentMax = maxTimeMs.get();
        } while (durationMs > currentMax && !maxTimeMs.compareAndSet(currentMax, durationMs));
        
        // Update type-specific counts
        switch (type) {
            case EXACT: exactMatchCount.incrementAndGet(); break;
            case RANGE: rangeQueryCount.incrementAndGet(); break;
            case PATTERN: patternQueryCount.incrementAndGet(); break;
            case FULLTEXT: fullTextQueryCount.incrementAndGet(); break;
            default: break;
        }
        
        // Track queries without index
        if (!hasIndex) {
            noIndexQueryCount.incrementAndGet();
        }
    }
    
    // Getters
    public String getFieldName() { return fieldName; }
    public long getTotalQueries() { return totalQueries.get(); }
    public long getTotalTimeMs() { return totalTimeMs.get(); }
    public long getMinTimeMs() { return minTimeMs.get(); }
    public long getMaxTimeMs() { return maxTimeMs.get(); }
    public long getExactMatchCount() { return exactMatchCount.get(); }
    public long getRangeQueryCount() { return rangeQueryCount.get(); }
    public long getPatternQueryCount() { return patternQueryCount.get(); }
    public long getFullTextQueryCount() { return fullTextQueryCount.get(); }
    public long getNoIndexQueryCount() { return noIndexQueryCount.get(); }
    
    /**
     * Get average query time in milliseconds.
     */
    public double getAverageTimeMs() {
        long total = totalQueries.get();
        return total > 0 ? totalTimeMs.get() / (double) total : 0;
    }
    
    /**
     * Check if queries on this field are slow.
     */
    public boolean isSlow() {
        return getAverageTimeMs() > SLOW_THRESHOLD_MS;
    }
    
    /**
     * Check if this field has pattern queries.
     */
    public boolean hasPatternQueries() {
        return patternQueryCount.get() > 0;
    }
    
    /**
     * Check if this field needs an index.
     */
    public boolean needsIndex() {
        return noIndexQueryCount.get() > 100 && isSlow();
    }
    
    /**
     * Get dominant query type.
     */
    public QueryType getDominantQueryType() {
        long exact = exactMatchCount.get();
        long range = rangeQueryCount.get();
        long pattern = patternQueryCount.get();
        long fulltext = fullTextQueryCount.get();
        
        long max = Math.max(Math.max(exact, range), Math.max(pattern, fulltext));
        
        if (max == 0) return null;
        if (max == exact) return QueryType.EXACT;
        if (max == range) return QueryType.RANGE;
        if (max == pattern) return QueryType.PATTERN;
        return QueryType.FULLTEXT;
    }
    
    @Override
    public String toString() {
        return String.format("QueryStats[%s: %d queries, avg=%.1fms, slow=%b]",
            fieldName, getTotalQueries(), getAverageTimeMs(), isSlow());
    }
}
