package org.garret.perst.smart;

/**
 * Confidence level for index recommendations.
 */
public enum Confidence {
    HIGH("Strong recommendation - clear signal"),
    MEDIUM("Good recommendation - likely beneficial"),
    LOW("Weak recommendation - consider reviewing");
    
    private final String description;
    
    Confidence(String description) {
        this.description = description;
    }
    
    public String getDescription() { return description; }
}
