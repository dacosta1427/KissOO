package org.garret.perst.continuous;

/**
 * Result of an optimistic locking operation.
 * Contains the outcome and any conflict information.
 */
public class StoreResult<T> {
    private final Status status;
    private final T object;
    private final long version;
    private final String message;
    private final long expectedVersion;
    private final long actualVersion;
    private final long oid;
    
    private StoreResult(Status status, T object, long version, String message, long oid, long expectedVersion, long actualVersion) {
        this.status = status;
        this.object = object;
        this.version = version;
        this.message = message;
        this.oid = oid;
        this.expectedVersion = expectedVersion;
        this.actualVersion = actualVersion;
    }
    
    /**
     * Create a successful result.
     * @param object the stored object (may be null for batch operations)
     * @param version the version ID
     */
    public static <T> StoreResult<T> success(T object, long version) {
        return new StoreResult<>(Status.SUCCESS, object, version, null, -1, -1, -1);
    }
    
    /**
     * Create a conflict result with detailed error message.
     * @param oid Object identifier that had the conflict
     * @param expectedVersion Version the caller expected
     * @param actualVersion Current version in database
     */
    public static <T> StoreResult<T> conflictWithDetails(long oid, long expectedVersion, long actualVersion) {
        String message = String.format(
            "Optimistic lock conflict on OID %d: expected version %d, but current version is %d. " +
            "Object was modified by another transaction. Re-fetch and retry.",
            oid, expectedVersion, actualVersion
        );
        return new StoreResult<>(Status.CONFLICT, null, actualVersion, message, oid, expectedVersion, actualVersion);
    }
    
    /**
     * Create an error result.
     * @param message error message
     */
    public static <T> StoreResult<T> error(String message) {
        return new StoreResult<>(Status.ERROR, null, -1, message, -1, -1, -1);
    }
    
    public enum Status {
        SUCCESS,
        CONFLICT,
        ERROR
    }
    
    public Status getStatus() { return status; }
    public T getObject() { return object; }
    public long getVersion() { return version; }
    public String getMessage() { return message; }
    public long getOid() { return oid; }
    public long getExpectedVersion() { return expectedVersion; }
    public long getActualVersion() { return actualVersion; }
    
    public boolean isSuccess() { return status == Status.SUCCESS; }
    public boolean isConflict() { return status == Status.CONFLICT; }
    public boolean isError() { return status == Status.ERROR; }
}
