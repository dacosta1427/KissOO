package org.garret.perst.continuous;

import org.garret.perst.*;
import java.util.Date;
import java.util.UUID;

/**
 * Base class for version of versioned object. All versions are kept in linear version history.
 */
public class CVersion extends Persistent
{
    private static final long serialVersionUID = 1L;

    public static final int FIRST_VERSION_ID = 1;

    /**
     * Get version history containing this version
     */
    @SuppressWarnings("unchecked")
    public <T extends CVersion> CVersionHistory<T> getVersionHistory() { 
        return (CVersionHistory<T>) history;
    }

    /**
     * Create working copy of this version
     * @return working copy of this version
     * @exception AmbiguousVersionException when some other version from the same version history was already updated by the current transaction
     * @exception TransactionNotStartedException if transaction was not started by this thread using CDatabase.beginTransaction
     */
    @SuppressWarnings("unchecked")
    public <T extends CVersion> T update() {         
        return (T)(((flags & WORKING_COPY) != 0) ? this : CDatabase.getWriteTransactionContext().update(this));
    }

    /**
     * Create working copy of this version and mark it as been deleted
     * @exception NotCurrentVersionException is thrown if this version is not current in version history
     * @exception TransactionNotStartedException if transaction was not started by this thread using CDatabase.beginTransaction
     */
    public void delete() 
    { 
        CVersion wc = ((flags & WORKING_COPY) != 0) ? this : CDatabase.getWriteTransactionContext().update(this);
        if (history.isCurrentForTransaction(wc, wc.transId)) {
            wc.flags |= DELETED;
        } else { 
            throw new NotCurrentVersionException(this);
        }
    }

    /**
     * Get date of version creation 
     * @return date when this version was created
     */
    public Date getDate() { 
        return date;
    }

    /**
     * Get identifier of the version. Version is version history are assigned sequential numbers starting from 1. 
     * @return version identifier automatically assigned by system.
     */
    public int getId() { 
        return id;
    }


    /**
     * Get identifier of transaction which has committed this version.
     * This identifier can be passed in CDatabase.beginTransaction method to obtain snapshot of the database at the 
     * moment of this transaction execution
     * @return identifier of transaction committed this version
     */
    public long getTransactionId() { 
        return transId;
    }

    /**
     * Check if specified version is the last version in the version history
     * @return true if it the last version in version history
     */
    public boolean isLastVersion() { 
        return id == history.getNumberOfVersions();
    }

    /**
     * Check if version corresponds to the deleted object. Object deletion is handled by marking version with DELETED 
     * flag. It is possible to create working copy of the deleted version and commit it - this is how undelete can 
     * be performed. So it can happen that multiple versions in version history are marked as been deleted, if
     * delete/undelete operations were repeated several times. 
     * @return true if the version is marked as deleted
     */
    public boolean isDeletedVersion() { 
        return (flags & CVersion.DELETED) != 0;
    }

    /**
     * Constructor of root version. All other versions should be created using 
     * <code>CVersionHistory.update</code> method
     */
    public CVersion(Storage storage) {
        super(storage);
        this._uuid = UUID.randomUUID().toString();
    }

    public CVersion() {
        this._uuid = UUID.randomUUID().toString();
    }

    CVersion createWorkingCopy(TableDescriptor desc) 
    { 
       try { 
           CVersion wc = (CVersion)clone();
           if (desc != null) { 
               desc.cloneFields(wc);
           }
           wc.clearState();
           wc.flags = (byte)WORKING_COPY;
           return wc;
        } catch (CloneNotSupportedException x) { 
            // Could not happen since we clone ourselves
            throw new AssertionFailed("Clone not supported");
        }
    }
           
    int  id; 
    long transId;
    Date date;
    CVersionHistory<?> history;
    String _uuid;  // Unique identifier for this version instance, used for Lucene indexing

    static final int NEW = 1;
    static final int DELETED = 2;
    static final int WORKING_COPY = 4;
    byte flags;

    /**
     * Get the unique identifier for this version.
     * @return UUID string unique to this version instance (same across all versions)
     */
    public String getUuid() {
        return _uuid;
    }

    /**
     * Serialize this entity to a JSONObject.
     * Uses cached reflection for efficient serialization.
     * 
     * Fields with @JsonIgnore are excluded.
     * CVersion references are serialized as OID by default.
     * Fields with @JsonIncludeObject are serialized inline.
     * 
     * @return JSONObject representation of this entity
     */
    public org.garret.perst.json.JSONObject toJSON() {
        return JsonSerializationCache.toJSON(this);
    }

    /**
     * Deserialize JSON into this entity (partial updates).
     * Only fields present in JSON will be updated.
     * 
     * @param json The JSON object to deserialize from
     * @return This entity (for chaining)
     */
    public <T extends CVersion> T fromJSON(org.garret.perst.json.JSONObject json) {
        return (T) JsonSerializationCache.fromJSON(this, json);
    }
}
