package org.garret.perst.continuous;

import java.util.*;

public class TransactionContainer {
    private String reference;
    private boolean syncToLin;
    private List<CVersion> insertList;
    private List<CVersion> updateList;
    private List<CVersion> deleteList;
    
    // For optimistic locking - tracks expected version for each object
    private Map<CVersion, Long> expectedVersions;

    public TransactionContainer() {
        insertList = new ArrayList<>();
        updateList = new ArrayList<>();
        deleteList = new ArrayList<>();
        expectedVersions = new HashMap<>();
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getReference() {
        return reference;
    }

    /**
     * Set this transaction to force Lin index commit (sync to disk).
     * Use for critical operations where you need guarantee that the
     * current version is persisted to Lin before returning.
     * 
     * Normal transactions: Lin write is async (Lucene buffers), .trloca handles recovery.
     * Critical transactions: Lin commit forced (sync), guaranteed on disk.
     */
    public void setSyncToLin(boolean syncToLin) {
        this.syncToLin = syncToLin;
    }

    public boolean isSyncToLin() {
        return syncToLin;
    }

    public void addInsert(CVersion obj) {
        insertList.add(obj);
    }

    /**
     * Add object for update with automatic optimistic lock version capture.
     * For persisted objects (OID >= 1), automatically captures the current
     * version ID from the object's version history for optimistic lock checking.
     * 
     * @param obj the CVersion object to update
     */
    public void addUpdate(CVersion obj) {
        updateList.add(obj);
        // Auto-capture expected version for persisted objects
        if (obj.getOid() > 0) {
            CVersionHistory<?> history = obj.getVersionHistory();
            if (history != null) {
                CVersion current = history.getCurrent();
                if (current != null && current.getId() >= 1) {
                    expectedVersions.put(obj, (long) current.getId());
                }
            }
        }
    }

    public void addUpdate(CVersion obj, long expectedVersion) {
        updateList.add(obj);
        expectedVersions.put(obj, expectedVersion);
    }

    public void addDelete(CVersion obj) {
        deleteList.add(obj);
    }

    public List<CVersion> getInsertList() {
        return insertList;
    }

    public List<CVersion> getUpdateList() {
        return updateList;
    }

    public List<CVersion> getDeleteList() {
        return deleteList;
    }
    
    public long getExpectedVersion(CVersion obj) {
        Long version = expectedVersions.get(obj);
        return version != null ? version : 0L;
    }

    public boolean isEmpty() {
        return insertList.isEmpty() && updateList.isEmpty() && deleteList.isEmpty();
    }

    public int size() {
        return insertList.size() + updateList.size() + deleteList.size();
    }
}
