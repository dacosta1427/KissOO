package org.garret.perst.continuous;

/**
 * Memory usage statistics for monitoring.
 */
public class MemoryStats {
    private final int totalCollections;
    private final int largeCollections;
    private final long totalEstimatedSize;
    
    public MemoryStats(int totalCollections, int largeCollections, long totalEstimatedSize) {
        this.totalCollections = totalCollections;
        this.largeCollections = largeCollections;
        this.totalEstimatedSize = totalEstimatedSize;
    }
    
    public int getTotalCollections() { return totalCollections; }
    public int getLargeCollections() { return largeCollections; }
    public long getTotalEstimatedSize() { return totalEstimatedSize; }
    
    public static MemoryStats current() {
        Runtime rt = Runtime.getRuntime();
        return new MemoryStats(0, 0, rt.totalMemory() - rt.freeMemory());
    }
    
    @Override
    public String toString() {
        return String.format("MemoryStats{collections=%d, large=%d, size=%d}", 
            totalCollections, largeCollections, totalEstimatedSize);
    }
}
