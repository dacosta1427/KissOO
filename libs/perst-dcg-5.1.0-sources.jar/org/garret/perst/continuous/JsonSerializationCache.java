package org.garret.perst.continuous;

import org.garret.perst.json.JSONObject;
import org.garret.perst.json.JSONArray;

import java.lang.reflect.Field;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * JSON serialization cache for CVersion entities.
 * Uses TableDescriptor's JSON field metadata for efficient serialization.
 * 
 * Design: Integrates with TableDescriptor's field scanning.
 * No external dependencies - uses minimal internal JSON implementation.
 */
public class JsonSerializationCache {
    
    // Cache: Class → Field metadata (for direct access without TableDescriptor)
    private static final Map<Class<?>, JsonFieldMetadata[]> fieldCache = new ConcurrentHashMap<>();
    
    /**
     * Pre-warm cache for entity class.
     * This forces TableDescriptor creation if not already done.
     * Optional - cache is automatically populated when TableDescriptor is created.
     * 
     * @param clazz The entity class to cache
     */
    public static void initialize(Class<?> clazz) {
        // TableDescriptor is created lazily, so this forces creation
        // The JSON fields are already scanned in TableDescriptor constructor
        // This method exists for explicit pre-warming if needed
        fieldCache.computeIfAbsent(clazz, JsonSerializationCache::buildFieldMetadata);
    }
    
    /**
     * Serialize entity to JSONObject.
     * Uses TableDescriptor's jsonFields if available, otherwise falls back to reflection.
     * 
     * @param entity The entity to serialize
     * @return JSONObject representation
     */
    public static JSONObject toJSON(CVersion entity) {
        if (entity == null) {
            return null;
        }
        
        JSONObject json = new JSONObject();
        
        // Add OID if entity is persistent
        if (entity.getStorage() != null && entity.getOid() > 0) {
            json.put("id", entity.getOid());
        }
        
        // Get JSON field info from entity's class
        JsonFieldInfo[] fields = getJsonFields(entity.getClass());
        
        for (JsonFieldInfo fieldInfo : fields) {
            // Skip ignored fields
            if (fieldInfo.ignore) {
                continue;
            }
            
            try {
                Object value = fieldInfo.field.get(entity);
                json.put(fieldInfo.jsonName, serializeValue(value, fieldInfo));
            } catch (IllegalAccessException e) {
                // Skip field on access error
            }
        }
        
        return json;
    }
    
    /**
     * Deserialize JSON into entity (partial updates).
     * Only fields present in JSON will be updated.
     * 
     * @param entity The entity to update
     * @param json The JSON data
     * @return The updated entity
     */
    public static <T extends CVersion> T fromJSON(T entity, JSONObject json) {
        if (entity == null || json == null) {
            return entity;
        }
        
        JsonFieldInfo[] fields = getJsonFields(entity.getClass());
        
        JSONArray keys = json.keys();
        for (int i = 0; i < keys.length(); i++) {
            String key = keys.getString(i);
            // Skip id field (read-only)
            if ("id".equals(key)) {
                continue;
            }
            
            // Find field info
            JsonFieldInfo fieldInfo = null;
            for (JsonFieldInfo fi : fields) {
                if (fi.jsonName.equals(key)) {
                    fieldInfo = fi;
                    break;
                }
            }
            
            // Skip if field not found or ignored
            if (fieldInfo == null || fieldInfo.ignore) {
                continue;
            }
            
            try {
                Object value = json.opt(key);
                if (value != null) {
                    Object converted = deserializeValue(value, fieldInfo);
                    fieldInfo.field.set(entity, converted);
                }
            } catch (IllegalAccessException e) {
                // Skip field on access error
            }
        }
        
        return entity;
    }
    
    /**
     * Serialize collection to JSONArray.
     * 
     * @param entities The collection to serialize
     * @return JSONArray of entity JSON objects
     */
    public static JSONArray toJSONArray(Collection<? extends CVersion> entities) {
        JSONArray array = new JSONArray();
        for (CVersion entity : entities) {
            array.put(toJSON(entity));
        }
        return array;
    }
    
    /**
     * Get JSON fields for a class, building metadata if needed.
     * First tries to get from TableDescriptor, falls back to reflection.
     */
    private static JsonFieldInfo[] getJsonFields(Class<?> clazz) {
        // Try to get from TableDescriptor first (if CDatabase is being used)
        // For now, use reflection-based metadata
        JsonFieldMetadata[] metadata = fieldCache.computeIfAbsent(
            clazz, JsonSerializationCache::buildFieldMetadata
        );
        
        // Convert to JsonFieldInfo array
        JsonFieldInfo[] result = new JsonFieldInfo[metadata.length];
        for (int i = 0; i < metadata.length; i++) {
            result[i] = metadata[i].toFieldInfo();
        }
        return result;
    }
    
    /**
     * Build field metadata for a class using reflection.
     * Similar to TableDescriptor.buildJsonFieldList but standalone.
     */
    private static JsonFieldMetadata[] buildFieldMetadata(Class<?> clazz) {
        List<JsonFieldMetadata> metadataList = new ArrayList<>();
        
        Class<?> current = clazz;
        while (current != null && CVersion.class.isAssignableFrom(current)) {
            for (Field field : current.getDeclaredFields()) {
                // Skip static and transient
                int mods = field.getModifiers();
                if (java.lang.reflect.Modifier.isStatic(mods) || 
                    java.lang.reflect.Modifier.isTransient(mods)) {
                    continue;
                }
                
                // Skip CVersion internal fields
                String name = field.getName();
                if (name.equals("history") || name.equals("flags") || 
                    name.equals("id") || name.equals("transId") || 
                    name.equals("date") || name.startsWith("_")) {
                    continue;
                }
                
                try {
                    field.setAccessible(true);
                } catch (Exception e) {
                    continue;
                }
                
                JsonFieldMetadata meta = new JsonFieldMetadata();
                meta.field = field;
                meta.jsonName = field.getName();
                meta.ignore = field.isAnnotationPresent(
                    org.garret.perst.annotations.JsonIgnore.class
                );
                meta.includeObject = field.isAnnotationPresent(
                    org.garret.perst.annotations.JsonIncludeObject.class
                );
                meta.isEntityReference = CVersion.class.isAssignableFrom(field.getType());
                meta.isCollection = Collection.class.isAssignableFrom(field.getType());
                meta.fieldType = field.getType();
                
                metadataList.add(meta);
            }
            current = current.getSuperclass();
        }
        
        // Sort by field name for consistent ordering
        metadataList.sort((m1, m2) -> m1.jsonName.compareTo(m2.jsonName));
        
        return metadataList.toArray(new JsonFieldMetadata[0]);
    }
    
    /**
     * Serialize a value based on field metadata.
     */
    private static Object serializeValue(Object value, JsonFieldInfo fieldInfo) {
        if (value == null) {
            return JSONObject.NULL;
        }
        
        // Entity reference handling
        if (fieldInfo.isEntityReference) {
            CVersion ref = (CVersion) value;
            if (fieldInfo.includeObject) {
                return toJSON(ref);  // Inline object
            } else {
                return ref.getOid();  // OID reference
            }
        }
        
        // Collection handling
        if (value instanceof Collection) {
            Collection<?> coll = (Collection<?>) value;
            JSONArray array = new JSONArray();
            for (Object item : coll) {
                if (item instanceof CVersion) {
                    CVersion ref = (CVersion) item;
                    if (fieldInfo.includeObject) {
                        array.put(toJSON(ref));
                    } else {
                        array.put(ref.getOid());
                    }
                } else {
                    array.put(item);
                }
            }
            return array;
        }
        
        // Primitive/String/Number - direct value
        return value;
    }
    
    /**
     * Deserialize a value based on field metadata.
     */
    private static Object deserializeValue(Object jsonValue, JsonFieldInfo fieldInfo) {
        if (jsonValue == null || jsonValue == JSONObject.NULL) {
            return null;
        }
        
        // For now, return as-is for simple types
        // Full deserialization (including entity references) would require storage access
        return jsonValue;
    }
    
    /**
     * Internal metadata class for JSON serialization.
     */
    private static class JsonFieldMetadata {
        Field field;
        String jsonName;
        boolean ignore;
        boolean includeObject;
        boolean isEntityReference;
        boolean isCollection;
        Class<?> fieldType;
        
        JsonFieldInfo toFieldInfo() {
            JsonFieldInfo info = new JsonFieldInfo();
            info.field = field;
            info.jsonName = jsonName;
            info.ignore = ignore;
            info.includeObject = includeObject;
            info.isEntityReference = isEntityReference;
            return info;
        }
    }
    
    /**
     * Runtime field info for serialization.
     * Complementary to TableDescriptor.JsonFieldInfo.
     */
    static class JsonFieldInfo {
        Field field;
        String jsonName;
        boolean ignore;
        boolean includeObject;
        boolean isEntityReference;
    }
}
