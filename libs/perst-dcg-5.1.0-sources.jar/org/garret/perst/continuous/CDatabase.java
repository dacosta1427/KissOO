package org.garret.perst.continuous;

import java.util.*;
import java.io.*;
import org.garret.perst.*;
import org.garret.perst.impl.ClassDescriptor;
import org.garret.perst.impl.MultiFile;

import org.apache.lucene.index.Term;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.FieldInfo;
import org.apache.lucene.index.LeafReaderContext;
import org.apache.lucene.index.LogByteSizeMergePolicy;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.DateTools;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.store.Directory;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * <p>
 * This class emulates relational database on top of Perst storage
 * It maintains class extends and associated indices. Is supports JSQL and full text search queries.
 * This class provides version control system, optimistic access control and full text search (using Lucene).
 * </p><p>
 * All transactions are isolated from each other and do not see changes made by other transactions 
 * (even committed transactions if commit happens after start of this transaction).
 * The database keeps all versions of the object hich are grouped in version history.
 * Version history is linear which means that no branches in version tree are possible. 
 * When transaction tries to update some object then working copy of the current version is created.
 * Only this copy is changed, leaving all other versions unchanged. This modification will be visible only
 * for the current transaction. Created or modified objects are linked in indices when transaction is committed.
 * It means that application will not be able to find in the index just inserted or updated object. It has 
 * first to commit the current transaction. All working copies created during transaction execution
 * are linked in he list stored in transaction context which is in turn associated with the current thread. 
 * It means two things:
 * <ol>
 * <li>one thread can participate in only one transaction and one transaction can be controlled only by one thread</li>
 * <li>size of transaction is limited by the amount of memory available for the application</li>
 * </ol>
 * When transaction is committed, then all its working copies are inspected. If the last version in version history is 
 * not equal to one from which working copy was created then conflict is detected and ConflictException is thrown.
 * And if insertion of working copy in index will cause unique constraint violation then NotUniqueException is thrown.
 * If no conflicts are detected, then transaction is committed and each working copy becomes new version in correspondent 
 * version history.
 * </p><p>
 * Isolation of transaction provided by CDatabase class is based on multiversioning and modification of working copies
 * instead of original objects. Working copy is produced from the current version using clone (shallow copy) method.
 * Clone will work correctly if components of the objects have primitive type (int, double,...) or are immutable (String). 
 * Using java.util.Date type is possible only if you do not try to update its components. 
 * Instead of normal Java references, you should use references to correspondent CVersionHistory (it allows to preserve 
 * reference consistency if new version of reference object is created).
 * CDatabase class also supports links (components with Link type) and arrays. 
 * Fields with <i>value type</i> (class implementing IValue interface) can be used only if them are 
 * immutable or cloneable (implement org.garret.perst.ICloneable interface). 
 * Using any other data type including Perst collection classes is not supported and can cause unpredictable behavior.
 */
@SuppressWarnings({"rawtypes", "unchecked"})
public class CDatabase {

    // ========================================================================
    // State Management
    // ========================================================================
    
    /**
     * Database state for lifecycle management.
     */
    public enum State {
        /** Database is open and accepting operations */
        OPEN,
        /** Database is closing - flushing resources, rejecting new operations */
        CLOSING,
        /** Database is closed - all operations are no-ops */
        CLOSED
    }
    
    private volatile State state = State.CLOSED;
    
    /**
     * Resource metrics for leak detection and monitoring.
     */
    public static class ResourceMetrics {
        private final java.util.concurrent.atomic.AtomicInteger activeTransactions = 
            new java.util.concurrent.atomic.AtomicInteger(0);
        private final java.util.concurrent.atomic.AtomicInteger openIterators = 
            new java.util.concurrent.atomic.AtomicInteger(0);
        private final java.util.concurrent.atomic.AtomicLong totalTransactions = 
            new java.util.concurrent.atomic.AtomicLong(0);
        private final java.util.concurrent.atomic.AtomicLong totalIterators = 
            new java.util.concurrent.atomic.AtomicLong(0);
        
        public void transactionStarted() {
            activeTransactions.incrementAndGet();
            totalTransactions.incrementAndGet();
        }
        
        public void transactionEnded() {
            activeTransactions.decrementAndGet();
        }
        
        public void iteratorOpened() {
            openIterators.incrementAndGet();
            totalIterators.incrementAndGet();
        }
        
        public void iteratorClosed() {
            openIterators.decrementAndGet();
        }
        
        public int getActiveTransactions() { return activeTransactions.get(); }
        public int getOpenIterators() { return openIterators.get(); }
        public long getTotalTransactions() { return totalTransactions.get(); }
        public long getTotalIterators() { return totalIterators.get(); }
        
        /**
         * Check if there are potential resource leaks.
         */
        public boolean hasPotentialLeaks() {
            return activeTransactions.get() > 0 || openIterators.get() > 0;
        }
        
        @Override
        public String toString() {
            return String.format("ResourceMetrics{activeTx=%d, openIter=%d, totalTx=%d, totalIter=%d}",
                activeTransactions.get(), openIterators.get(), 
                totalTransactions.get(), totalIterators.get());
        }
    }
    
    private final ResourceMetrics resourceMetrics = new ResourceMetrics();
    
    /** 
     * Open the database. This method initialize database if it not initialized yet.
     * @param storage opened storage. Storage should be either empty (non-initialized, either
     * previously initialized by the this method. It is not possible to open storage with 
     * root object other than RootObject  created by this method.
     * @param fullTextIndexPath path to the directory containing Lucene database. If null, then Lucene index will be stored 
     * inside the main Perst storage.
     */
    public void open(Storage storage, String fullTextIndexPath) 
    { 
        if (state == State.OPEN && this.storage != null) {
            throw new IllegalStateException("Database is already open");
        }
        // Allow re-opening after close (for test cleanup/reopen scenarios)
        
        this.storage = storage;
        storage.setProperty("perst.concurrent.iterator", Boolean.TRUE);
        state = State.OPEN;
        
        // Read Lin/Lex configuration from storage properties
        Object bufferSizeProp = storage.getProperty("PerstHistoryBufferSize");
        if (bufferSizeProp != null) {
            try {
                historyBufferSize = Integer.parseInt(bufferSizeProp.toString());
            } catch (NumberFormatException e) {
                // Keep default value
            }
        }
        
        Object flushIntervalProp = storage.getProperty("PerstHistoryFlushInterval");
        if (flushIntervalProp != null) {
            try {
                historyFlushInterval = Integer.parseInt(flushIntervalProp.toString());
            } catch (NumberFormatException e) {
                // Keep default value
            }
        }
        
        root = (RootObject)storage.getRoot();
        typeMap = new HashMap<Class,TableDescriptor>();
        if (root == null) { 
            root = new RootObject(storage);
            storage.setRoot(root);
        } else { 
            for (TableDescriptor desc : root.tables) { 
                typeMap.put(desc.type, desc);                
            }
            for (TableDescriptor desc : typeMap.values()) { 
                buildInheritanceHierarchy(desc);
            }
        }
        openFullTextIndex(root, fullTextIndexPath);
        
        // Open history index (Lex) for Lin/Lex split architecture
        // History index path is derived from fullTextIndexPath with .lex suffix
        if (fullTextIndexPath != null) {
            openHistoryIndex(fullTextIndexPath + ".lex");
            
            // Initialize transaction tracker for crash recovery
            // Use the same base path as the full text index
            transactionTracker = new TransactionTracker(fullTextIndexPath);
            
            // Check for recovery needed (existence of .trloca files indicates unclean shutdown)
            File indexDir = new File(fullTextIndexPath);
            if (indexDir.exists() && indexDir.isDirectory()) {
                File[] trlocaFiles = indexDir.listFiles((d, name) -> name.endsWith(".trloca"));
                if (trlocaFiles != null && trlocaFiles.length > 0) {
                    // Recovery needed - replay transactions and rebuild history
                    HistoryRecovery.recover(fullTextIndexPath, this);
                }
            }
            
            // Start asynchronous history flushing
            startAsyncHistoryFlush();
        }
        
        storage.commit();
    }

    /**
     * Open database using MultiFile with specified segment paths and sizes.
     * This provides a convenient way to create a database spread across multiple files.
     * 
     * @param segmentPaths Array of file paths for each segment
     * @param segmentSizes Array of sizes in bytes for each segment (last segment can be 0 for unlimited growth)
     * @param fullTextIndexPath Path to Lucene index directory, or null for embedded storage
     * @throws StorageError if segment arrays are invalid or file access fails
     */
    public void openMultiFile(String[] segmentPaths, long[] segmentSizes, String fullTextIndexPath) {
        if (segmentPaths == null || segmentSizes == null) {
            throw new IllegalArgumentException("Segment paths and sizes cannot be null");
        }
        if (segmentPaths.length != segmentSizes.length) {
            throw new IllegalArgumentException("Segment paths and sizes arrays must have same length");
        }
        if (segmentPaths.length == 0) {
            throw new IllegalArgumentException("Must specify at least one segment");
        }
        
        MultiFile multiFile = new MultiFile(segmentPaths, segmentSizes, false, false);
        Storage storage = StorageFactory.getInstance().createStorage();
        
        try {
            storage.open(multiFile, Storage.DEFAULT_PAGE_POOL_SIZE);
        } catch (StorageError ex) {
            multiFile.close();
            throw ex;
        }
        
        open(storage, fullTextIndexPath);
    }

    /**
     * Open database using MultiFile with a configuration file.
     * The config file format is:
     * <pre>
     * segment1.db 102400   # 100 MB
     * segment2.db 204800   # 200 MB
     * segment3.db          # unlimited size
     * </pre>
     * 
     * @param configFilePath Path to the MultiFile configuration file
     * @param fullTextIndexPath Path to Lucene index directory, or null for embedded storage
     * @throws StorageError if configuration file is invalid or file access fails
     */
    public void openMultiFile(String configFilePath, String fullTextIndexPath) {
        if (configFilePath == null) {
            throw new IllegalArgumentException("Config file path cannot be null");
        }
        
        MultiFile multiFile = new MultiFile(configFilePath, false, false);
        Storage storage = StorageFactory.getInstance().createStorage();
        
        try {
            storage.open(multiFile, Storage.DEFAULT_PAGE_POOL_SIZE);
        } catch (StorageError ex) {
            multiFile.close();
            throw ex;
        }
        
        open(storage, fullTextIndexPath);
    }

    /**
     * Open database using a custom IFile implementation.
     * This allows for custom file implementations like encrypted, compressed, or multi-file.
     * 
     * @param file Custom IFile implementation
     * @param fullTextIndexPath Path to Lucene index directory, or null for embedded storage
     * @throws StorageError if file cannot be opened
     */
    public void open(IFile file, String fullTextIndexPath) {
        if (file == null) {
            throw new IllegalArgumentException("File cannot be null");
        }
        
        Storage storage = StorageFactory.getInstance().createStorage();
        
        try {
            storage.open(file, Storage.DEFAULT_PAGE_POOL_SIZE);
        } catch (StorageError ex) {
            file.close();
            throw ex;
        }
        
        open(storage, fullTextIndexPath);
    }

    /**
     * Close the database. All uncommitted transaction will be aborted.
     * Close full text index and storage.
     */
    public void close() 
    { 
        // Guard against double close using state machine
        if (state == State.CLOSED || state == State.CLOSING) {
            return;  // Already closed or closing
        }
        
        state = State.CLOSING;
        
        // Warn about potential resource leaks
        if (resourceMetrics.hasPotentialLeaks()) {
            System.err.println("WARNING: Closing database with potentially leaked resources: " + 
                resourceMetrics);
        }
        
        try { 
            if (indexWriter != null) { 
                indexWriter.close();
                indexWriter = null;
            }
            if (indexReader != null) { 
                indexReader.close();
                indexReader = null;
            }
            if (dir != null) { 
                dir.close();
                dir = null;
            }
            
            // Close history index (Lex) for Lin/Lex split architecture
            if (historyIndexEnabled) {
                flushHistoryBuffer(); // Flush any remaining history
                if (historyIndexWriter != null) {
                    historyIndexWriter.close();
                    historyIndexWriter = null;
                }
                if (historyDir != null) {
                    historyDir.close();
                    historyDir = null;
                }
            }
        } catch (IOException x) { 
            state = State.CLOSED;  // Ensure state is set even on error
            throw new IOError(x);
        }
        storage.close();
        storage = null;

        // Cleanup transaction tracker
        if (transactionTracker != null) {
            transactionTracker.shutdown();
            transactionTracker = null;
        }

        // Stop asynchronous history flushing
        stopAsyncHistoryFlush();

        // Clean up transaction context to prevent memory leaks
        TransactionContext ctx = transactionContext.get();
        if (ctx != null && ctx.db == this) {
            ctx.endTransaction();
            transactionContext.remove();
        }

        root = null;
        typeMap = null;
        analyzer = null;
        historyBuffer = null;
        state = State.CLOSED;
    }

    /**
     * Get the current state of the database.
     * @return the current state (OPEN, CLOSING, or CLOSED)
     */
    public State getState() {
        return state;
    }

    /**
     * Get resource metrics for monitoring and leak detection.
     * @return the resource metrics
     */
    public ResourceMetrics getResourceMetrics() {
        return resourceMetrics;
    }

    /**
     * Start new transaction. All changes can be made only within transaction context. 
     * Transaction context is associated with thread. It means that one thread can run only one transaction and
     * one transaction can be handled only by one thread. 
     * Transaction is observing database state at the moment of the transaction start. Any changes done by
     * other transactions (committed and uncommitted) after this moment are not visible for the current transaction.
     * CDatabase uses optimistic access control. It means that transaction may be aborted if conflict 
     * is detected during transaction commit.
     */
    public void beginTransaction() 
    {
        beginTransaction(root.getLastTransactionId());
    }

    /**
     * Start transaction with the given identifier. 
     * Identifier of the transaction can be obtained using CVersion.getTransactionId() method.
     * Starting transaction with ID of previously committed transaction allows to obtain snapshot
     * of the database at the moment of this transaction execution. All search methods
     * using default version selector (referencing current version) and CVersionHistory.getCurrent()
     * method will select versions which were current at the moment of this transaction execution.
     * @param transId identifier of previously committed transaction
     * @exception TransactionAlreadyStartedException when thread attempts to start new transaction without committing or 
     * aborting previous one. Transaction should be explicitly finished using CDatabase.commit or CDatabase.rollback method.
     * Each thread should start its own transaction, it is not possible to share the same transaction by more than one threads.
     * It is possible to call beginTransaction several times without commit or rollback only if previous transaction was read-only 
     * - didn't change any object
     */
    public synchronized void beginTransaction(long transId) 
    {
        if (state != State.OPEN) {
            throw new IllegalStateException("Cannot begin transaction: database is " + state);
        }
        if (root == null) {
            throw new IllegalStateException("Cannot begin transaction: database not initialized");
        }
        
        TransactionContext ctx = getTransactionContext();
        if (ctx == null) { 
            ctx = new TransactionContext(this);
            transactionContext.set(ctx);
            resourceMetrics.transactionStarted();
        }
        ctx.beginTransaction(transId, ++maxTransSeqNo);
    }

    /**
     * Commit a transaction container. All objects in the container are processed
     * as a single atomic transaction (all-or-nothing).
     * 
     * <p>TransactionContainer (TrC) provides a standard way to bundle multiple object
     * operations (INSERT/UPDATE/DELETE) into a single atomic transaction. All objects
     * either succeed together or fail together (fast-fail).</p>
     * 
     * <p>Example usage:</p>
     * <pre>
     * TransactionContainer trc = new TransactionContainer();
     * trc.setReference("TX-123"); // optional reference stored in Ldoc
     * trc.addInsert(newCompany);
     * trc.addInsert(newEmployee);
     * trc.addUpdate(existingCompany);
     * db.commit(trc);
     * </pre>
     * 
     * <p>Each TrC generates a single transaction ID applied to all contained objects.
     * This enables full Lucene index recovery from transaction logs.</p>
     * 
     * @param trc the transaction container with objects to insert, update, or delete
     * @return identifier assigned to this transaction
     * @exception ConflictException if conflict with other transaction was detected
     * @exception NotUniqueException if unique constraint violation was detected
     */
    public long commit(TransactionContainer trc) 
    {
        String reference = trc.getReference();
        if (reference != null) {
            trcReference.set(reference);
        }
        // Set sync-to-Lin flag from container
        syncToLinFlag.set(trc.isSyncToLin());
        // Set flag: if transaction succeeds, create .trloca file
        needsTrlocaFile = !trc.isEmpty();
        try {
            beginTransaction();
            try {
                for (CVersion obj : trc.getInsertList()) {
                    insert(obj);
                }
                for (CVersion obj : trc.getUpdateList()) {
                    update(obj);
                }
                for (CVersion obj : trc.getDeleteList()) {
                    obj.delete();
                }
                return commitTransaction();
            } catch (RuntimeException e) {
                rollbackTransaction();
                throw e;
            }
        } finally {
            trcReference.remove();
            syncToLinFlag.remove();
            needsTrlocaFile = false;  // Reset flag
        }
    }

    /**
     * Store all objects in container with early optimistic lock validation.
     * 
     * <p>This method performs pre-validation BEFORE acquiring the exclusive lock,
     * which provides fail-fast behavior for conflicting transactions. This reduces
     * lock contention in high-concurrency scenarios.</p>
     * 
     * <p>Difference from commit(TransactionContainer):</p>
     * <ul>
     *   <li>{@code commit()}: validates inside lock (legacy behavior)</li>
     *   <li>{@code store()}: validates BEFORE lock (fail-fast, less contention)</li>
     * </ul>
     * 
     * <p>Validation checks:</p>
     * <ol>
     *   <li>For each UPDATE object: compare expected version with current version</li>
     *   <li>If any mismatch → return StoreResult.conflict() immediately (no lock acquired)</li>
     *   <li>If all OK → proceed with commit inside lock</li>
     * </ol>
     * 
     * @param trc the transaction container with objects to insert, update, or delete
     * @return StoreResult with SUCCESS, CONFLICT, or ERROR status
     */
    public StoreResult store(TransactionContainer trc) {
        if (trc == null) {
            return StoreResult.error("TransactionContainer cannot be null");
        }
        if (trc.isEmpty()) {
            return StoreResult.success(null, 0);
        }
        
        // ===== PHASE 1: PRE-VALIDATION (NO LOCK) =====
        // Check optimistic locks for all UPDATE objects BEFORE acquiring lock
        // Note: We use getLast() instead of getCurrent() because getCurrent() may return
        // working copies when called during a transaction, which would give incorrect version IDs
        for (CVersion obj : trc.getUpdateList()) {
            Long expectedVersion = trc.getExpectedVersion(obj);
            if (expectedVersion != null && obj.getOid() > 0) {
                CVersionHistory<?> history = obj.getVersionHistory();
                if (history != null) {
                    CVersion current = history.getLast();  // Use getLast() for actual current version
                    if (current != null && current.getId() != expectedVersion.longValue()) {
                        // Conflict detected - return immediately without acquiring lock
                        return StoreResult.conflictWithDetails(
                            obj.getOid(),
                            expectedVersion,
                            current.getId()
                        );
                    }
                }
            }
        }
        
        // ===== PHASE 2: COMMIT (WITH LOCK, BUT VALIDATION ALREADY PASSED) =====
        String reference = trc.getReference();
        if (reference != null) {
            trcReference.set(reference);
        }
        syncToLinFlag.set(trc.isSyncToLin());
        needsTrlocaFile = !trc.isEmpty();
        
        try {
            beginTransaction();
            try {
                for (CVersion obj : trc.getInsertList()) {
                    insert(obj);
                }
                for (CVersion obj : trc.getUpdateList()) {
                    update(obj);
                }
                for (CVersion obj : trc.getDeleteList()) {
                    obj.delete();
                }
                long transId = commitTransaction();
                return StoreResult.success(null, transId);
            } catch (ConflictException e) {
                rollbackTransaction();
                // This should be rare since we pre-validated
                CVersion conflictedVersion = e.getVersion();
                return StoreResult.conflictWithDetails(
                    conflictedVersion != null ? conflictedVersion.getOid() : -1,
                    -1,  // Expected version unknown at this point
                    -1   // Actual version unknown at this point
                );
            } catch (RuntimeException e) {
                rollbackTransaction();
                return StoreResult.error(e.getMessage());
            }
        } finally {
            trcReference.remove();
            syncToLinFlag.remove();
            needsTrlocaFile = false;
        }
    }

    /**
     * Convenience method for quick single-object update.
     * Handles beginTransaction, creates working copy, applies changes, and commits.
     * 
     * <p>Example usage:</p>
     * <pre>
     *   StoreResult result = db.update(oid, obj -> {
     *       obj.setName("newName");
     *       obj.setValue(42);
     *   });
     *   if (result.isConflict()) { ... }
     * </pre>
     * 
     * @param oid object identifier
     * @param updater consumer that modifies the working copy
     * @return StoreResult indicating success, conflict, or error
     */
    @SuppressWarnings("unchecked")
    public <T extends CVersion> StoreResult update(long oid, java.util.function.Consumer<T> updater) {
        if (oid <= 0) {
            return StoreResult.error("Invalid OID: " + oid);
        }
        if (updater == null) {
            return StoreResult.error("Updater cannot be null");
        }
        
        boolean wasInTransaction = isInTransaction();
        long expectedVersion = -1;
        
        try {
            if (!wasInTransaction) {
                beginTransaction();
            }
            
            T workingCopy = getUpdateObject(oid);
            if (workingCopy == null) {
                if (!wasInTransaction) rollbackTransaction();
                return StoreResult.error("Object not found: OID " + oid);
            }
            
            // Capture version for conflict info
            expectedVersion = ((CVersion) workingCopy).getId();
            
            // Apply user's modifications
            updater.accept(workingCopy);
            
            if (!wasInTransaction) {
                commitTransaction();
            }
            
            return StoreResult.success(workingCopy, ((CVersion) workingCopy).getId());
            
        } catch (ConflictException e) {
            if (!wasInTransaction) rollbackTransaction();
            return StoreResult.conflictWithDetails(oid, expectedVersion, -1);
        } catch (Exception e) {
            if (!wasInTransaction) rollbackTransaction();
            return StoreResult.error("Update failed: " + e.getMessage());
        }
    }

    /**
     * Commit transaction. 
     * @exception ConflictExpetion is thrown if object modified by this transaction was also changed by some other 
     * previously committed transaction 
     * @exception NotUniqueException is thrown if indexable field with unique constraint of inserted or updated object 
     * contains the same value as current version of some other instance of this class (committed by another transact).
     * Please notice that CDatabase is not able to detect unique constraint violations within one transaction - if it
     * inserts two instances with same value of indexable field.
     * @return identifier assigned to this transaction or 0 if there is no active transaction. 
     * This identifier can be used to obtain snapshot of the database at the moment of this transaction execution.
     */
    public long commitTransaction() throws ConflictException, NotUniqueException 
     { 
        if (state != State.OPEN) {
            throw new IllegalStateException("Cannot commit transaction: database is " + state);
        }
        
        TransactionContext ctx = getTransactionContext();
        if (ctx == null || ctx.transId == TransactionContext.IMPLICIT_TRANSACTION_ID) { 
            return 0;
        }
        if (ctx.isEmptyTransaction() && !root.isModified()) { 
            ctx.endTransaction();
            resourceMetrics.transactionEnded();
            return ctx.transId;
        }
        
         // Set flag: create .trloca if transaction has work
        Collection<CVersion> workSet = ctx.getWorkingCopies();
        needsTrlocaFile = !workSet.isEmpty();
        
        // Determine first operation type BEFORE clearing flags in commit loop
        String firstOperation = null;
        int firstObjectId = 0;
        if (needsTrlocaFile && transactionTracker != null) {
            CVersion firstObj = workSet.iterator().next();
            firstObjectId = firstObj.getOid();
            if ((firstObj.flags & CVersion.NEW) != 0) {
                firstOperation = "INSERT";
            } else if ((firstObj.flags & CVersion.DELETED) != 0) {
                firstOperation = "DELETE";
            } else {
                firstOperation = "UPDATE";
            }
        }
        
        root.exclusiveLock();
        try { 
            long transId = ctx.transId;
            for (CVersion v : workSet) {
                if ((v.flags & CVersion.NEW) == 0 && v.history.getLast().transId > transId) { 
                    throw new ConflictException(v);
                }
                TableDescriptor desc = lookupTable(v.getClass());
                if (desc != null) { 
                    desc.checkConstraints(v);
                }
            }
            if (ctx.seqNo == minTransSeqNo) { 
                minTransSeqNo += 1;
                if (ctx.transId > lastActiveTransId) { 
                    lastActiveTransId = ctx.transId;
                }
            }
            transId = root.newTransactionId();
            for (CVersion v : workSet) { 
                @SuppressWarnings("unchecked")
                CVersionHistory<CVersion> vh = (CVersionHistory<CVersion>) v.history;
                TableDescriptor desc = getTable(v.getClass());
                int flags = v.flags;

                v.transId = transId;
                v.id = vh.getNumberOfVersions() + 1;
                v.flags &= ~(CVersion.WORKING_COPY|CVersion.NEW);
                v.date = new Date();
                vh.add(v);

                if ((flags & (CVersion.NEW|CVersion.DELETED)) == CVersion.NEW) { 
                    TableDescriptor td = desc;
                    do { 
                        td.classExtent.add(vh);
                    } while ((td = td.supertable) != null);                        
                } else if (vh.limited) { 
                    CVersion old;
                    while ((old = vh.get(CVersion.FIRST_VERSION_ID)).transId < lastActiveTransId) {
                        desc.excludeFromIndices(old);
                        excludeFromFullTextIndex(desc, old);
                        vh.remove(CVersion.FIRST_VERSION_ID);
                        old.deallocate();
                    }
                }
                // Lin/Lex split: Add document to history buffer for Lex index
                // This MUST happen AFTER current object indexing to ensure consistency
                if (historyIndexEnabled) {
                    if ((flags & CVersion.NEW) == 0) {
                        // For updates (not new inserts), add previous version to history
                        // Note: vh.add(v) was already called, so getLast() returns v
                        // We need to get the second-to-last version
                        CVersion previousVersion = null;
                        int numVersions = vh.getNumberOfVersions();
                        if (numVersions > 1) {
                            previousVersion = vh.get(numVersions - 1); // Get version at index numVersions-2 (0-based)
                        }
                        if (previousVersion != null && previousVersion != v) {
                            Document historyDoc = desc.buildDocument(previousVersion);
                            if (historyDoc != null) {
                                historyBuffer.add(historyDoc);
                            }
                        }
                    } else if ((flags & CVersion.DELETED) == 0) {
                        // For new inserts, add the new version to history as well
                        Document historyDoc = desc.buildDocument(v);
                        if (historyDoc != null) {
                            historyBuffer.add(historyDoc);
                        }
                    }
                    
                    // For deletions, add a deletion record to history
                    if ((flags & CVersion.DELETED) != 0) {
                        Document historyDoc = desc.buildDocument(v);
                        if (historyDoc != null) {
                            // Mark the document as a deletion record
                            // This could be done by adding a special field to the document
                            historyBuffer.add(historyDoc);
                        }
                    }
                }
                
                if ((flags & CVersion.DELETED) == 0) {
                    desc.includeInIndices(v); 
                    includeInFullTextIndex(desc.buildDocument(v));
                }
                
            }      
            
            // Create .trloca marker if transaction succeeded and flag is set
            // Use pre-computed operation (determined before flags were cleared)
            if (needsTrlocaFile && transactionTracker != null && firstOperation != null) {
                transactionTracker.markIfAbsent(transId, firstObjectId, firstOperation);
            }
            
            // Note: History buffer flushing is handled asynchronously by the background thread.
            // This ensures transaction commits never block on I/O operations.
            // See startAsyncHistoryFlush() for the async flush mechanism.
            
            // Handle Lin writes with appropriate error handling
            boolean linWriteFailed = false;
            try {
                if (indexWriter != null) { 
                    if (syncToLinFlag.get()) {
                        // IMMEDIATE transaction: Lin errors are fatal
                        indexWriter.close();
                        indexWriter = null;
                    } else {
                        // Normal transaction: Lin errors are non-fatal
                        // Main DB commit succeeds, Lin can be recovered later
                        try {
                            indexWriter.commit();
                        } catch (IOException linError) {
                            // Log error but don't fail the transaction
                            System.err.println("WARNING: Lin commit failed (will recover via .trloca): " + linError.getMessage());
                            linWriteFailed = true;
                        }
                    }
                }
                if (indexReader != null) {
                    indexReader.close();
                    indexReader = null;
                }
            } catch (IOException x) { 
                // Only throw if this was a sync/IMMEDIATE transaction
                if (syncToLinFlag.get()) {
                    throw new IOError(x);
                }
                // For async transactions, log and continue
                System.err.println("WARNING: Lin operation failed (non-fatal): " + x.getMessage());
            }
            transactionCount++;
            if (optimizeInterval > 0 && transactionCount % optimizeInterval == 0) {
                optimizeFullTextIndex();
            }
            storage.commit();
            return transId;
        } finally { 
            root.unlock();         
            ctx.endTransaction();
            resourceMetrics.transactionEnded();
        }
    }
    
    /**
     * Rollback transaction
     */
    public void rollbackTransaction() 
    { 
        TransactionContext ctx = getTransactionContext();
        if (ctx != null && root != null) { 
            root.exclusiveLock();
            try { 
                if (ctx.seqNo == minTransSeqNo) { 
                    minTransSeqNo += 1;
                    if (ctx.transId > lastActiveTransId) { 
                        lastActiveTransId = ctx.transId;
                    }
                }
            } finally { 
                root.unlock();         
                ctx.endTransaction();
                resourceMetrics.transactionEnded();
            }
        } else if (ctx != null) {
            // Root is null (database closed), just clean up context
            ctx.endTransaction();
            resourceMetrics.transactionEnded();
        }
    }

    /**
     * Insert new record in the database
     * @param record inserted record
     * @exception ObjectAlreadyInsertedException when object is part of some other version history
     * @exception TransactionNotStartedException if transaction was not started by this thread using CDatabase.beginTransaction
     */
    public <T extends CVersion> void insert(T record) 
    { 
        getWriteTransactionContext().insert(record);
    }

    /**
     * Update the record. 
     * @param record updated record
     * @return working copy of the specified version
     * @exception AmbiguousVersionException when some other version from the same version history was already updated by the current transaction
     * @exception TransactionNotStartedException if transaction was not started by this thread using CDatabase.beginTransaction
     */
    @SuppressWarnings("unchecked")
    public <T extends CVersion> T update(T record) { 
        return (T)record.update();
    }

    /**
     * Mark current version as been deleted.
     * @param record working copy of the current version or current version itself. In the last case work copy is created
     * @exception NotCurrentVersionException is thrown if specified version is not current in the version history
     * @exception TransactionNotStartedException if transaction was not started by this thread using CDatabase.beginTransaction
     */
    public void delete(CVersion record) { 
        record.delete();
    }

    // ========================================================================
    // OID/UUID Lookup Methods (convenience methods for object retrieval)
    // ========================================================================

    /**
     * Get object by OID (object identifier).
     * Returns the raw object from storage (may not be latest version).
     * @param oid object identifier
     * @return the object, or null if not found
     */
    public <T extends CVersion> T getByOid(long oid) {
        if (storage == null || oid <= 0) {
            return null;
        }
        try {
            Object obj = storage.getObjectByOID((int) oid);
            return (obj instanceof CVersion) ? (T) obj : null;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Get the LATEST version of an object by OID.
     * Returns the current version from the version history.
     * Use this after updates to get the most recent version.
     * @param oid object identifier
     * @return latest version, or null if not found
     */
    @SuppressWarnings("unchecked")
    public <T extends CVersion> T getLatestByOid(long oid) {
        if (storage == null || oid <= 0) {
            return null;
        }
        try {
            Object obj = storage.getObjectByOID((int) oid);
            if (obj == null || !(obj instanceof CVersion)) {
                return null;
            }
            
            CVersion version = (CVersion) obj;
            CVersionHistory<?> history = version.getVersionHistory();
            if (history == null) {
                return (T) version;  // No history, return as-is
            }
            
            // Return the CURRENT (latest) version from history
            return (T) history.getCurrent();
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Get object by UUID using full-text search.
     * @param uuid the object's UUID string
     * @return the object, or null if not found
     */
    @SuppressWarnings("unchecked")
    public <T extends CVersion> T getByUuid(String uuid) {
        try {
            FullTextSearchResult[] results = fullTextSearch("_UUID:" + uuid, 1);
            if (results != null && results.length > 0) {
                return (T) results[0].getVersion();
            }
        } catch (Exception e) {
            // UUID not found or search error
        }
        return null;
    }

    // ========================================================================
    // Version Helper Methods
    // ========================================================================

    /**
     * Get the current version from a version history.
     * @param versionHistory the version history
     * @return current version, or null if history is null or empty
     */
    public <T extends CVersion> T getCurrent(CVersionHistory<T> versionHistory) {
        if (versionHistory == null) {
            return null;
        }
        return versionHistory.getCurrent();
    }

    /**
     * Get a working copy for update, with automatic transaction management.
     * If not in a transaction, begins one automatically.
     * @param versionHistory the version history
     * @return working copy ready for modification
     * @throws IllegalArgumentException if versionHistory is null
     * @throws IllegalStateException if history has no current version
     */
    @SuppressWarnings("unchecked")
    public <T extends CVersion> T getVersionForUpdate(CVersionHistory<T> versionHistory) {
        if (versionHistory == null) {
            throw new IllegalArgumentException("Version history cannot be null");
        }
        
        T current = versionHistory.getCurrent();
        if (current == null) {
            throw new IllegalStateException("Version history has no current version");
        }
        
        // Begin transaction if not already in one
        if (!isInTransaction()) {
            beginTransaction();
        }
        
        // Get working copy via history.update()
        return (T) versionHistory.update();
    }

    /**
     * Get an updatable working copy of an object by OID.
     * Returns a clone that can be modified and added to TransactionContainer.
     * Automatically begins a transaction if not already in one.
     * 
     * @param oid object identifier (must be > 0)
     * @return working copy ready for modification, or null if not found/invalid
     */
    @SuppressWarnings("unchecked")
    public <T extends CVersion> T getUpdateObject(long oid) {
        if (storage == null || oid <= 0) {
            return null;
        }
        
        try {
            Object obj = storage.getObjectByOID((int) oid);
            if (obj == null || !(obj instanceof CVersion)) {
                return null;
            }
            
            CVersion version = (CVersion) obj;
            CVersionHistory<?> history = version.getVersionHistory();
            if (history == null) {
                return null;
            }
            
            // Begin transaction if not already in one
            if (!isInTransaction()) {
                beginTransaction();
            }
            
            // Get working copy (clone) via history.update()
            return (T) history.update();
        } catch (Exception e) {
            return null;
        }
    }

    // ========================================================================
    // TransactionContainer Factory Methods
    // ========================================================================

    /**
     * Create a new TransactionContainer for batch operations.
     * Normal async Lin writes.
     * @return new TransactionContainer
     */
    public TransactionContainer createContainer() {
        return new TransactionContainer();
    }

    /**
     * Create a TransactionContainer with sync-to-Lin enabled.
     * Use for operations that must guarantee Lin is committed to disk.
     * @return new TransactionContainer with syncToLin=true
     */
    public TransactionContainer createSyncContainer() {
        TransactionContainer trc = new TransactionContainer();
        trc.setSyncToLin(true);
        return trc;
    }

    // ========================================================================
    // Transaction Status Methods
    // ========================================================================

    /**
     * Check if currently in a transaction (for current thread).
     * @return true if the current thread is inside a transaction
     */
    public boolean isInTransaction() {
        TransactionContext ctx = transactionContext.get();
        return ctx != null && ctx.transId != TransactionContext.IMPLICIT_TRANSACTION_ID;
    }

    /**
     * Extract single result from the returned result set.
     * It should be applied as pipeline to CDatabase.select/CDatabase.find/CDatabase.getRecords/Query.execute methods:
     * <code>
     *    MyClass obj = db.getSingleton(db.find(MyClass.class, "key", value));
     * </code>
     * @param iterator result set iterator returned by CDatabase.select/CDatabase.find/CDatabase.getRecords/Query.execute
     * methods
     * @return selected object if result set contains exactly one object or null if result set is empty
     * @exception SingletonException if result set contains more than one element
     */     
    public <T extends CVersion> T getSingleton(Iterator<T> iterator) throws SingletonException
    { 
        root.sharedLock();
        try { 
            T obj = null;
            if (iterator.hasNext()) { 
                obj = iterator.next();
                if (iterator.hasNext()) {  
                    throw new SingletonException();
                }
            }
            return obj;
        } finally { 
            root.unlock();
        } 
    }

    /**
     * Enumeration specifying version sort order in the result set.
     * Sorting is performed by version identifier
     */
    public static class VersionSortOrder 
    {
        public static final int ASCENT = 1;
        public static final int NONE = 0;
        public static final int DESCENT = -1;
        
        private final int delta;
        
        private VersionSortOrder(int delta) {
            this.delta = delta;
        }
        
        public static final VersionSortOrder ASCENT_ORDER = new VersionSortOrder(ASCENT);
        public static final VersionSortOrder NONE_ORDER = new VersionSortOrder(NONE);
        public static final VersionSortOrder DESCENT_ORDER = new VersionSortOrder(DESCENT);
    }

    /**
     * Convert returned result set to the List collection. 
     * It should be applied as pipeline to CDatabase.select/CDatabase.find/CDatabase.getRecords/Query.execute methods:
     * <code>
     *    List<MyClass> list = db.toList(db.select(MyClass.class, "price between 100 and 1000 and amount > 100"));
     * </code>
     * Result set iterator usually selects records in Perst in lazy mode, so execution of query is very 
     * fast but fetching each element requires some additional calculations. 
     * Using this method you can force loading of all result set elements. So you will know
     * precise number of selected records, can access them in any order and without extra overhead.
     * The payment for these advantages is increased time of query execution and amount of memory needed
     * to hold all selected objects.
     * @param iterator result set iterator returned by CDatabase.select/CDatabase.find/CDatabase.getRecords/Query.execute
     * methods
     * @return List containing all selected objects
     */     
    public <T extends CVersion> List<T> toList(Iterator<T> iterator) 
    { 
        return toList(iterator, Integer.MAX_VALUE);
    }

    /**
     * Converted returned result set to List collection with limit for number of fetched records. 
     * It should be applied as pipeline to CDatabase.select/CDatabase.find/CDatabase.getRecords/Query.execute methods:
     * <code>
     *    List<MyClass> list = db.toList(db.select(MyClass.class, "price between 100 and 1000 and amount > 100"));
     * </code>
     * Result set iterator usually selects records in Perst in lazy mode, so execution of query is very 
     * fast but fetching each element requires some additional calculations. 
     * Using this method you can force loading of all result set elements. So you will know
     * precise number of selected results, can access them in any order and without extra overhead.
     * The payment for these advantages is increased time of query execution and amount of memory needed
     * to hold all selected objects.
     * @param iterator result set iterator returned by CDatabase.select/CDatabase.find/CDatabase.getRecords/Query.execute
     * methods
     * @param limit result list limit
     * @return List containing selected objects, if number of selected objects is larger than specified <code>limit</code>, 
     * then only first <code>limit</code> of them will be placed in the list and other will be ignored.
     */         
    public <T extends CVersion> List<T> toList(Iterator<T> iterator, int limit)
    { 
        ArrayList<T> list = new ArrayList<>();
        root.sharedLock();
        try { 
            while (--limit >= 0 && iterator.hasNext()) { 
                list.add(iterator.next());
            } 
            return list;
        } finally { 
            root.unlock();
        } 
    }

    /**
     * Converted returned result set to array.
     * It should be applied as pipeline to CDatabase.select/CDatabase.find/CDatabase.getRecords/Query.execute methods:
     * <code>
     *    MyClass[] arr = db.toArray(new MyClass[0], db.select(MyClass.class, "price between 100 and 1000 and amount > 100", 
     *                                                         VersionSortOrder.ASCENT));
     * </code>
     * Result set iterator usually selects records in Perst in lazy mode, so execution of query is very 
     * fast but fetching each element requires some additional calculations. 
     * Using this method you can force loading of all result set elements. So you will know
     * precise number of selected results, can access them in any order and without extra overhead.
     * The payment for these advantages is increased time of query execution and amount of memory needed
     * to hold all selected objects.
     * Specifying sort order allows for example to select the first/last version satisfying search criteria.
     * @param arr the array into which the elements of the list are to be stored, 
     * if it is big enough; otherwise, a new array of the same runtime type is allocated for this purpose.
     * @param iterator result set iterator returned by CDatabase.select/CDatabase.find/CDatabase.getRecords/Query.execute
     * methods
     * @param order version sort order: ASCENT, DESCENT or NONE. Array elements will be sorted by version identifiers. 
     * If sort order is not specified NONE (then records in the result array will be in the same order as returned by the iterator)
     * @return an array containing selected objects in the given order
     */         
    public <T extends CVersion> T[] toArray(T[] arr, Iterator<T> iterator, VersionSortOrder order) 
    { 
        ArrayList<T> list = new ArrayList<>();
        root.sharedLock();
        try { 
            while (iterator.hasNext()) { 
                list.add(iterator.next());
            }
        } finally { 
            root.unlock();
        }
        arr = list.toArray(arr);
        if (order != VersionSortOrder.NONE_ORDER) { 
            final int delta = order.delta;
            Arrays.sort(arr, new Comparator<T>() { 
                            public int compare(T v1, T v2) { 
                                return v1.transId < v2.transId ? -delta : v1.transId == v2.transId ? 0 : delta;
                            }
                        });
        }
        return arr;
    }
    
    /**
     * Select current version of records from specified table matching specified criteria
     * @param table class corresponding to the table
     * @param predicate search predicate
     * @return iterator through selected records. This iterator doesn't support remove() method.
     * If there are no instances of such class in the database, then empty iterator is returned
     * @exception CompileError exception is thrown if predicate is not valid JSQL exception
     * @exception JSQLRuntimeException exception is thrown if there is runtime error during query execution
     */
    public <T extends CVersion> IterableIterator<T> select(Class table, String predicate) 
    { 
        return select(table, predicate, VersionSelector.CURRENT);
    }
        
    /**
     * Select records from the specified table using version selector
     * @param table class corresponding to the table
     * @param predicate search predicate
     * @param selector version selector
     * @return iterator through selected records. This iterator doesn't support remove() method.
     * If there are no instances of such class in the database, then empty iterator is returned
     * @exception CompileError exception is thrown if predicate is not valid JSQL exception
     * @exception JSQLRuntimeException exception is thrown if there is runtime error during query execution
     */
    @SuppressWarnings("unchecked")
    public <T extends CVersion> IterableIterator<T> select(Class table, String predicate, VersionSelector selector)
    { 
        Query<T> q = prepare(table, predicate);
        return q.execute(getRecords(table, selector));
    }

    /**
     * Prepare JSQL query. Prepare is needed for queries with parameters. Also
     * preparing query can improve speed if query will be executed multiple times
     * (using prepare, it is compiled only once).
     * To execute prepared query, you should use Query.execute(db.getRecords(TABLE.class)) method
     * @param table class corresponding to the table
     * @param predicate search predicate
     * @return prepared query
     * @exception CompileError exception is thrown if predicate is not valid JSQL exception
     */
    public <T extends CVersion> Query<T> prepare(Class table, String predicate) 
    { 
        return prepare(table, predicate, VersionSelector.CURRENT);
    }

    /**
     * Prepare JSQL query. Prepare is needed for queries with parameters. Also
     * preparing query can improve speed if query will be executed multiple times
     * (using prepare, it is compiled only once).
     * To execute prepared query, you should use Query.execute(db.getRecords(TABLE.class)) method
     * @param table class corresponding to the table
     * @param predicate search predicate
     * @param selector version selector
     * @return prepared query
     * @exception CompileError exception is thrown if predicate is not valid JSQL exception
     */
    @SuppressWarnings("unchecked")
    public <T extends CVersion> Query<T> prepare(Class table, String predicate, VersionSelector selector) 
    { 
        Query<T> q = storage.createQuery();
        q.prepare(table, predicate);            
        TableDescriptor desc = lookupTable(table);
        if (desc != null) { 
            desc.registerIndices(q, root, selector);
        }
        return q;
    }

    /** 
     * Get iterator through current version of all table records
     * @param table class corresponding to the table
     * @return iterator through all table records. If there are no instances of such class in the database, then empty
     * iterator is returned
     */
    public <T extends CVersion> IterableIterator<T> getRecords(Class table)
    {
        return getRecords(table, VersionSelector.CURRENT);
    }

    /** 
     * Get iterator through all records of the table using specified version selector
     * @param table class corresponding to the table
     * @param selector version selector
     * @return iterator through all table records. If there are no instances of such class in the database, then empty
     * iterator is returned
     */
    public <T extends CVersion> IterableIterator<T> getRecords(Class table, VersionSelector selector)
    {         
        long startTime = System.currentTimeMillis();
        root.sharedLock();
        try { 
            TableDescriptor desc = lookupTable(table);        
            IterableIterator<T> iterator = (desc == null) 
                ? new EmptyIterator<T>() 
                : new ExtentIterator<T>(desc.iterator(), root, selector);
            
            // Track iterator for resource leak detection
            resourceMetrics.iteratorOpened();
            
            // Log query for smart index analysis
            long duration = System.currentTimeMillis() - startTime;
            recordQuery(table.getName(), org.garret.perst.smart.QueryType.ALL_RECORDS, duration, false);
            
            // Wrap in tracking iterator that decrements on completion
            return new TrackedIterator<>(iterator, resourceMetrics);
        } finally { 
            root.unlock();
        } 
    }

    /**
     * Select current version from specified table by key
     * @param table class corresponding to the table
     * @param field indexed field
     * @param key key value
     * @return iterator through selected records. This iterator doesn't support remove() method.
     * If there are no instances of such class in the database, then empty iterator is returned
     * @exception NoSuchIndexException if there is no index for the specified field
     */
    public <T extends CVersion> IterableIterator<T> find(Class table, String field, Key key) throws NoSuchIndexException 
    {
        return find(table, field, key, VersionSelector.CURRENT);
    }

    /**
     * Select records from the specified table by key using version selector
     * @param table class corresponding to the table
     * @param field indexed field
     * @param key key value
     * @param selector version selector
     * @return iterator through selected records. This iterator doesn't support remove() method.
     * If there are no instances of such class in the database, then empty iterator is returned
     * @exception NoSuchIndexException if there is no index for the specified field
     */
    public <T extends CVersion> IterableIterator<T> find(Class table, String field, Key key, VersionSelector selector) throws NoSuchIndexException 
    {
        long startTime = System.currentTimeMillis();
        TableDescriptor desc = lookupTable(table);
        if (desc == null) { 
            return new EmptyIterator<T>();
        }
        TableDescriptor.IndexDescriptor idesc = desc.findIndex(field);
        if (idesc == null) { 
            throw new NoSuchIndexException(field);
        }
        key = idesc.checkKey(key);
        IterableIterator<T> result = new IndexFilter<T>(idesc, root, selector).iterator(key, key, GenericIndex.ASCENT_ORDER);
        
        // Log query for smart index analysis
        long duration = System.currentTimeMillis() - startTime;
        recordQuery(field, classifyKeyType(key), duration, idesc != null);
        
        return result;
    }
    
    /**
     * Classify a Key to determine query type for smart index logging.
     */
    private org.garret.perst.smart.QueryType classifyKeyType(Key key) {
        if (key == null) {
            return org.garret.perst.smart.QueryType.EXACT;
        }
        
        // Check for string keys with wildcards
        if (key.oval instanceof String) {
            String str = (String) key.oval;
            if (str.endsWith("*")) {
                return org.garret.perst.smart.QueryType.PREFIX;
            }
            if (str.contains("*") || str.contains("?")) {
                return org.garret.perst.smart.QueryType.PATTERN;
            }
        }
        
        // Check for compound keys (arrays)
        if (key.oval instanceof Object[]) {
            return org.garret.perst.smart.QueryType.RANGE;
        }
        
        return org.garret.perst.smart.QueryType.EXACT;
    }

    /**
     * Select records from the specified table by key range using version selector
     * @param table class corresponding to the table
     * @param field indexed field
     * @param min minimal key value
     * @param max maximal key value
     * @param selector version selector
     * @param order key sort order: GenericIndex.ASCENT_ORDER or GenericIndex.DESCENT_ORDER
     * @return iterator through selected records. This iterator doesn't support remove() method.
     * If there are no instances of such class in the database, then empty iterator is returned
     * @exception NoSuchIndexException if there is no index for the specified field
     */
    public <T extends CVersion> IterableIterator<T> find(Class table, String field, Key min, Key max, VersionSelector selector, int order)
    {
        TableDescriptor desc = lookupTable(table);
        if (desc == null) { 
            return new EmptyIterator<T>();
        }
        TableDescriptor.IndexDescriptor idesc = desc.findIndex(field);
        if (idesc == null) { 
            throw new NoSuchIndexException(field);
        }
        return new IndexFilter<T>(idesc, root, selector).iterator(idesc.checkKey(min), idesc.checkKey(max), order);
    }

    /**
     * Perform full text search through the current version of all objects in the database
     * @param query full text search search query. It should be compliant with Lucene query syntax and may
     * refer to the particular fields or to any full text searchable field:
     * <ul>
     * <li>"name:John" - select document with field "name" containing word "John"</li>
     * <li>"title:magic AND author:Clark" - select document with field "title" containing word "magic" and field "author"
     *                                     containing word "Clark"</li>
     * <li>"atomic nuclear power" - select any document which full text searchable fields contain any of the specified words</li>
     * <li>"Class:com.eshop.Player AND description:DivX" - select objects with class com.eshop.Player which description contains word "DivX"</li>
     * </ul>
     * @param limit search result limit 
     * @return array with matched documents
     * @exception FullTextSearchQuerySyntaxError if query syntax is invalid
     */
    public FullTextSearchResult[] fullTextSearch(String query, int limit)
    {
        return fullTextSearch(query, limit, VersionSelector.CURRENT, VersionSortOrder.NONE_ORDER);
    }

    /**
     * Perform full text search using version selector
     * @param query full text search search query. It should be compliant with Lucene query syntax and may
     * refer to the particular fields or to any full text searchable field:
     * <ul>
     * <li>"name:John" - select document with field "name" containing word "John"</li>
     * <li>"title:magic AND author:Clark" - select document with field "title" containing word "magic" and field "author"
     *                                     containing word "Clark"</li>
     * <li>"atomic nuclear power" - select any document which full text searchable fields contain any of the specified words</li>
     * <li>"Class:com.eshop.Player AND description:DivX" - select objects with class com.eshop.Player which description contains word "DivX"</li>
     * </ul>
     * @param limit search result limit 
     * @param selector version selector
     * @param order result set versions sort order (if VersionSortOrder.NONE then order of documents returned by Lucene 
     * is preserved - documents are sorted by score)
     * @return array with matched documents
     * @exception FullTextSearchQuerySyntaxError if query syntax is invalid
     */
    public FullTextSearchResult[] fullTextSearch(String query, int limit, VersionSelector selector, VersionSortOrder order)
    {
        long startTime = System.currentTimeMillis();
        ArrayList<FullTextSearchResult> result = null;
        IndexSearcher searcher;
        TopDocs hits;
        root.sharedLock();
        try { 
            try { 
                searcher = new IndexSearcher(getIndexReader());
                if (selector.kind == VersionSelector.Kind.TimeSlice) { 
                    long from = selector.from != null ? selector.from.getTime() : 0;
                    long till = selector.till != null ? selector.till.getTime() : System.currentTimeMillis();
                    StringBuilder sb = new StringBuilder("Created:[");
                    sb.append(DateTools.timeToString(from, DateTools.Resolution.MINUTE));
                    sb.append(" TO ");
                    sb.append(DateTools.timeToString(till, DateTools.Resolution.MINUTE));
                    sb.append("] AND (");
                    sb.append(query);
                    sb.append(')');
                    query = sb.toString();
                }
                QueryParser parser = new QueryParser("Any", analyzer);
                org.apache.lucene.search.Query parsedQuery = parser.parse(query);
                hits = searcher.search(parsedQuery, limit > 0 ? limit : 1000);
            } catch (IOException x) {
                throw new IOError(x);
            } catch (ParseException x) { 
                throw new FullTextSearchQuerySyntaxError(x);
            } 
            result = new ArrayList<FullTextSearchResult>(limit > 0 ? limit : (limit = hits.scoreDocs.length));
            Iterator<FullTextSearchResult> iterator = new FullTextSearchIterator(hits, searcher, storage, selector);
            while (--limit >= 0 && iterator.hasNext()) { 
                result.add(iterator.next());
            }
        } finally { 
            root.unlock();
        }
        
        // Log query for smart index analysis
        long duration = System.currentTimeMillis() - startTime;
        recordQuery("_fulltext", org.garret.perst.smart.QueryType.FULLTEXT, duration, true); 
        FullTextSearchResult[] arr = result.toArray(new FullTextSearchResult[result.size()]);
        if (order != VersionSortOrder.NONE_ORDER) { 
            final int delta = order.delta;
            Arrays.sort(arr, new Comparator<FullTextSearchResult>() { 
                            public int compare(FullTextSearchResult r1, FullTextSearchResult r2) { 
                                long t1 = r1.getVersion().transId;
                                long t2 = r2.getVersion().transId;
                                return t1 < t2 ? -delta : t1 == t2 ? 0 : delta;
                            }
                        });
        }
        return arr;
    }

    /**
     * Restore full text search index.
     * If the full text search index is located in file system directory it may be get out of sync with the Perst database or even be 
     * corrupted in case of failure. In this case index can be reconstructed using this method.
     */
    public synchronized void restoreFullTextIndex()
    {
        root.exclusiveLock();
        try { 
            try { 
                if (indexWriter != null) { 
                    indexWriter.close();
                }
                if (indexReader != null) { 
                    indexReader.close();
                    indexReader = null;
                }
                IndexWriterConfig iwc = new IndexWriterConfig(analyzer);
                iwc.setMergePolicy(new LogByteSizeMergePolicy());
                indexWriter = new IndexWriter(dir, iwc);
                for (TableDescriptor table : root.tables) {
                    for (CVersionHistory<?> vh : table) {
                        for (CVersion v : vh) { 
                            if (!v.isDeletedVersion()) { 
                                Document doc = table.buildDocument(v);
                                if (doc != null) { 
                                    indexWriter.addDocument(doc);
                                }
                            }
                        }
                    }
                }                                       
                indexWriter.forceMerge(1);
            } catch (IOException x) {
                throw new IOError(x);
            }
        } finally { 
            root.unlock();
        }
    }

    /**
     * Optimize full text index. This method can be periodically called by application (preferably in idle time)
     * to optimize full text search index
     */
    public synchronized void optimizeFullTextIndex() 
    {
        root.exclusiveLock();
        try { 
            try { 
                getIndexWriter().forceMerge(1);
            } catch (IOException x) {
                throw new IOError(x);
            }
        } finally { 
            root.unlock();
        }
    }
        

    /**
     * Gets the path to the history index directory.
     * @return The index path
     */
    public String getHistoryIndexPath() {
        return historyIndexPath;
    }

    /**
     * Gets the current size of the history buffer.
     * @return The number of documents in the history buffer
     */
    public int getHistoryBufferSize() {
        return historyBuffer != null ? historyBuffer.size() : 0;
    }

    /**
     * Triggers an asynchronous flush of the history buffer to the Lex index.
     * This method returns immediately without blocking.
     * The actual flush is performed by the background thread.
     * 
     * @return true if a flush was triggered, false if buffer is empty or history is disabled
     */
    public boolean flushHistory() {
        if (!historyIndexEnabled || historyBuffer == null || historyBuffer.isEmpty()) {
            return false;
        }
        // Signal the async thread to flush immediately by updating lastFlushTime
        lastFlushTime = 0;
        return true;
    }

    /**
     * Waits for the history buffer to be flushed.
     * This is useful for testing to ensure async flush completes.
     * 
     * @param maxWaitMs maximum time to wait in milliseconds
     * @return true if buffer is empty, false if timeout occurred
     */
    public boolean waitForHistoryFlush(long maxWaitMs) {
        long startTime = System.currentTimeMillis();
        while (historyBuffer != null && !historyBuffer.isEmpty()) {
            if (System.currentTimeMillis() - startTime > maxWaitMs) {
                return false;
            }
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return false;
            }
        }
        return true;
    }


    /**
     * Get resource used to synchronize access to the database
     */
    public IResource getResource() 
    { 
        return root;
    }

    /**
     * Get storage associated with this database
     * @return underlying storage
     */
    public Storage getStorage() 
    { 
        return storage;
    }

    /**
     * Get user data. Continuous uses Perst root objects for its own purposes. 
     * But this methods allows application to specify its own root and store in the Perst 
     * storage non-versioned objects. 
     * @return reference to the persistent object previously stored by setUserData()
     */
    public IPersistent getUserData() 
    { 
        root.sharedLock();
        try { 
            return root.userData;
        } finally { 
            root.unlock();
        }
    }

     /**
     * Set user data. Continuous uses Perst root objects for its own purposes. 
     * But this methods allows application to specify its own root and store in the Perst 
     * storage non-versioned objects. 
     * @param obj reference to the persistent object which will be stored in Perst root object
     */
    public void setUserData(IPersistent obj) 
    { 
        root.exclusiveLock();
        try { 
            root.userData = obj;
            root.modify();
        } finally { 
            root.unlock();
        }
    }
    
    /**
     * Get collection all of field names 
     */
    public Collection<String> getAllFullTextSearchanbleFieldNames() throws Exception {
       Set<String> fieldNames = new HashSet<>();
       IndexReader reader = getIndexReader();
       for (LeafReaderContext ctx : reader.leaves()) {
           for (FieldInfo info : ctx.reader().getFieldInfos()) {
               fieldNames.add(info.name);
           }
       }
       return fieldNames;
    }

    /**
     * Static instance of the database which can be used by application working with the single database
     */
    public static CDatabase instance = new CDatabase();


    static TransactionContext getTransactionContext() 
    { 
        return transactionContext.get();
    }

    static TransactionContext getWriteTransactionContext() 
    { 
        TransactionContext ctx = transactionContext.get();
        if (ctx == null) { 
            throw new TransactionNotStartedException();
        }            
        return ctx;
    }

    void openFullTextIndex(RootObject root, String path)
    {
        boolean create;
        if (path == null) { 
            throw new IllegalArgumentException("Full text index path must be specified in Lucene 9.x - in-Perst storage is temporarily disabled");
        }
        File file = new File(path);
        create = !file.exists();
        try { 
            dir = FSDirectory.open(java.nio.file.Paths.get(path));
            
            if (!create && !org.apache.lucene.index.DirectoryReader.indexExists(dir)) {
                create = true;
            }
        } catch (IOException x) {
            throw new IOError(x);
        }
        analyzer = new StandardAnalyzer();
        try { 
            IndexWriterConfig iwc = new IndexWriterConfig(analyzer);
            iwc.setOpenMode(create ? IndexWriterConfig.OpenMode.CREATE : IndexWriterConfig.OpenMode.APPEND);
            iwc.setMergePolicy(new LogByteSizeMergePolicy());
            indexWriter = new IndexWriter(dir, iwc);
        } catch (IOException x) {
            throw new IOError(x);
        }
    }

    /**
     * Opens the history index (Lex) for the Lin/Lex split architecture.
     * The history index stores all non-current versions of objects.
     * @param path Path to the history index directory
     */
    void openHistoryIndex(String path)
    {
        if (path == null) {
            return; // History index is optional
        }
        
        this.historyIndexPath = path;
        try {
            File file = new File(path);
            boolean create = !file.exists();
            
            historyDir = FSDirectory.open(java.nio.file.Paths.get(path));
            
            if (!create && !org.apache.lucene.index.DirectoryReader.indexExists(historyDir)) {
                create = true;
            }
            
            IndexWriterConfig iwc = new IndexWriterConfig(analyzer);
            iwc.setOpenMode(create ? IndexWriterConfig.OpenMode.CREATE : IndexWriterConfig.OpenMode.APPEND);
            iwc.setMergePolicy(new LogByteSizeMergePolicy());
            
            historyIndexWriter = new IndexWriter(historyDir, iwc);
            historyBuffer = new ConcurrentLinkedQueue<>();
            historyIndexEnabled = true;
            lastFlushTime = System.currentTimeMillis();
        } catch (IOException x) {
            throw new IOError(x);
        }
    }
    
    /**
     * Gets the current history buffer size threshold.
     * @return The maximum number of documents before automatic flush
     */
    public int getHistoryBufferThreshold() {
        return historyBufferSize;
    }
    
    /**
     * Gets the current flush interval in seconds.
     * @return Time interval between automatic flushes
     */
    public int getHistoryFlushInterval() {
        return historyFlushInterval;
    }

    void excludeFromFullTextIndex(TableDescriptor desc, CVersion v) 
    {
        if (desc.isFullTextSearchable()) { 
            Term term = new Term("Oid", Integer.toString(v.getOid()));
            try { 
                getIndexWriter().deleteDocuments(term);
            } catch (IOException x) { 
                throw new IOError(x);
            }
        }
    }
    

    void includeInFullTextIndex(Document doc)
    {
        if (doc != null) { 
            try { 
                getIndexWriter().addDocument(doc);
            } catch (IOException x) {
                throw new IOError(x);
            }
        }
    }

    /**
     * Flushes the history buffer to the Lex index.
     * This method is called periodically by the async background thread.
     */
    synchronized void flushHistoryBuffer()
    {
        if (!historyIndexEnabled || historyBuffer == null || historyBuffer.isEmpty()) {
            return;
        }
        
        try {
            Document doc;
            while ((doc = historyBuffer.poll()) != null) {
                if (doc != null) {
                    historyIndexWriter.addDocument(doc);
                }
            }
            // Commit the changes to make them persistent
            historyIndexWriter.commit();
        } catch (IOException x) {
            throw new IOError(x);
        }
    }
    
    /**
     * Add a document to the history buffer (for recovery purposes).
     * This allows recovered transactions to be processed by the periodic flush mechanism.
     * 
     * @param doc The document to add to the history buffer
     */
    synchronized void addToHistoryBuffer(Document doc)
    {
        if (!historyIndexEnabled || doc == null) {
            return;
        }
        
        historyBuffer.add(doc);
    }
    
    /**
     * Flush the history buffer (for recovery purposes).
     * This forces immediate flushing of buffered history documents.
     */
    public synchronized void flushHistoryBufferImmediately()
    {
        flushHistoryBuffer();
    }
    
    /**
     * Start asynchronous history flushing background thread.
     * This thread periodically checks and flushes the history buffer to the Lex index.
     * Runs every 100ms for responsiveness, but actual flush respects the configured interval.
     */
    private void startAsyncHistoryFlush() {
        if (historyFlushExecutor != null && !historyFlushExecutor.isShutdown()) {
            return; // Already started
        }
        
        historyFlushExecutor = Executors.newScheduledThreadPool(1, r -> {
            Thread t = new Thread(r, "CDatabase-HistoryFlush");
            t.setDaemon(true);
            return t;
        });
        
        // Schedule checking every 100ms for responsiveness
        // Actual flush respects the configured historyFlushInterval
        historyFlushExecutor.scheduleAtFixedRate(() -> {
            try {
                if (!shutdownRequested && historyIndexEnabled && historyBuffer != null && !historyBuffer.isEmpty()) {
                    long currentTime = System.currentTimeMillis();
                    boolean timeIntervalExceeded = (currentTime - lastFlushTime) > (historyFlushInterval * 1000L);
                    
                    if (historyBuffer.size() > historyBufferSize || timeIntervalExceeded) {
                        flushHistoryBuffer();
                        lastFlushTime = currentTime;
                    }
                }
            } catch (Exception e) {
                // Log error but don't stop the background thread
                System.err.println("Error in async history flush: " + e.getMessage());
            }
        }, 100, 100, TimeUnit.MILLISECONDS);  // Check every 100ms for responsiveness
    }
    
    /**
     * Stop asynchronous history flushing.
     * This method should be called during database shutdown.
     */
    private void stopAsyncHistoryFlush() {
        shutdownRequested = true;
        if (historyFlushExecutor != null && !historyFlushExecutor.isShutdown()) {
            try {
                historyFlushExecutor.shutdown();
                if (!historyFlushExecutor.awaitTermination(30, TimeUnit.SECONDS)) {
                    historyFlushExecutor.shutdownNow();
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                historyFlushExecutor.shutdownNow();
            }
        }
    }

    synchronized TableDescriptor lookupTable(Class type)
    {
        return typeMap.get(type);
    }

    synchronized TableDescriptor getTable(Class type)
    {
        TableDescriptor desc = typeMap.get(type);
        if (desc == null) { 
            desc = new TableDescriptor(storage, type);
            buildInheritanceHierarchy(desc);
            typeMap.put(type, desc);
            root.tables.add(desc);
        }
        return desc;
    }
    
    /**
     * Gets all table descriptors in the database.
     * @return Collection of all table descriptors
     */
    public java.util.Collection<TableDescriptor> getTableDescriptors() {
        return typeMap.values();
    }

    // ========================================================================
    // JSON Serialization Support
    // ========================================================================

    /**
     * Pre-warm JSON serialization cache for entity class.
     * Forces TableDescriptor creation (which scans JSON annotations).
     * Optional - JSON fields are automatically scanned when TableDescriptor is created.
     * 
     * Use this at startup for performance-critical classes to avoid
     * lazy initialization overhead on first use.
     * 
     * @param entityClass The entity class to initialize
     */
    public void buildJsonFieldList(Class<? extends CVersion> entityClass) {
        getTable(entityClass);  // Forces TableDescriptor creation with JSON scanning
    }

    /**
     * Pre-warm JSON serialization cache for multiple entity classes.
     * 
     * @param entityClasses The entity classes to initialize
     */
    public void buildJsonFieldList(Class<? extends CVersion>... entityClasses) {
        for (Class<? extends CVersion> clazz : entityClasses) {
            buildJsonFieldList(clazz);
        }
    }

    void buildInheritanceHierarchy(TableDescriptor desc) { 
        Class superclass = desc.type.getSuperclass();
        if (superclass != CVersion.class) {             
            desc.supertable = getTable(superclass);
        }
    }
           
    synchronized IndexWriter getIndexWriter() throws IOException 
    {
        if (indexWriter == null) { 
            if (indexReader != null) { 
                indexReader.close();
                indexReader = null;
            }
            IndexWriterConfig iwc = new IndexWriterConfig(analyzer);
            iwc.setMergePolicy(new LogByteSizeMergePolicy());
            indexWriter = new IndexWriter(dir, iwc);
        }
        return indexWriter;
    }

    synchronized IndexReader getIndexReader() throws IOException 
    {             
        if (indexReader == null) { 
            if (indexWriter != null) { 
                indexWriter.close();
                indexWriter = null;
            }
            indexReader = DirectoryReader.open(dir);
        }
        return indexReader;
    }

    static ThreadLocal<TransactionContext> transactionContext = new ThreadLocal<TransactionContext>();
    static ThreadLocal<String> trcReference = new ThreadLocal<String>();
    public static ThreadLocal<Boolean> syncToLinFlag = ThreadLocal.withInitial(() -> false);

    public static String getTrcReference() {
        return trcReference.get();
    }
    
    public static boolean isSyncToLin() {
        return syncToLinFlag.get();
    }

    Storage storage;
    RootObject root;
    HashMap<Class,TableDescriptor> typeMap;   
    IndexWriter indexWriter;
    IndexReader indexReader;
    StandardAnalyzer analyzer;
    Directory dir;
    long minTransSeqNo;
    long maxTransSeqNo;
    long lastActiveTransId;
    private int transactionCount = 0;
    private int optimizeInterval = 1000;  // configurable
    
    // Lin/Lex split architecture - History index management
    private IndexWriter historyIndexWriter;
    private Directory historyDir;
    private java.util.concurrent.ConcurrentLinkedQueue<Document> historyBuffer;
    private boolean historyIndexEnabled = false;
    private String historyIndexPath;
    
    // Transaction log tracking for crash recovery
    private TransactionTracker transactionTracker;
    private boolean needsTrlocaFile = false;  // Flag: create .trloca on successful commit
    
    // Asynchronous history flushing
    private ScheduledExecutorService historyFlushExecutor;
    private volatile boolean shutdownRequested = false;
    
    // Configuration variables with defaults
    private int historyBufferSize = 1000;  // Configurable via PerstHistoryBufferSize
    private volatile int historyFlushInterval = 300;  // Configurable via PerstHistoryFlushInterval (seconds)
    private volatile long lastFlushTime = System.currentTimeMillis();

    public void setOptimizeInterval(int interval) {
        this.optimizeInterval = interval;
    }
    
    /**
     * Set the history buffer size threshold for automatic flushing.
     * @param size Number of documents before automatic flush
     */
    public void setHistoryBufferSize(int size) {
        this.historyBufferSize = size;
    }
    
    /**
     * Set the flush interval in seconds.
     * @param seconds Time interval between automatic flushes
     */
    public void setHistoryFlushInterval(int seconds) {
        this.historyFlushInterval = seconds;
    }

    // ========================================================================
    // Smart Index Management
    // ========================================================================
    
    private org.garret.perst.smart.IndexRecommendationEngine recommendationEngine;
    private org.garret.perst.smart.QueryLogger queryLogger;
    private boolean queryLoggingEnabled = true;
    
    /**
     * Initialize smart index components.
     * Called automatically during open() if not already initialized.
     */
    private void initSmartIndex() {
        if (recommendationEngine == null) {
            recommendationEngine = new org.garret.perst.smart.IndexRecommendationEngine(this);
            queryLogger = recommendationEngine.getQueryLogger();
        }
    }
    
    /**
     * Analyze a CVersion class and return comprehensive index recommendations.
     * Combines static field analysis with dynamic query pattern analysis.
     * @param clazz The CVersion class to analyze
     * @return Recommendations with field analyses, action items, and query insights
     */
    public org.garret.perst.smart.Recommendations analyzeAndSuggest(Class<? extends CVersion> clazz) {
        initSmartIndex();
        return recommendationEngine.analyze(clazz);
    }
    
    /**
     * Get prioritized list of index optimization suggestions.
     * Based on accumulated query patterns and static analysis.
     * @return List of action items sorted by impact
     */
    public java.util.List<org.garret.perst.smart.ActionItem> getOptimizationSuggestions() {
        initSmartIndex();
        java.util.List<org.garret.perst.smart.ActionItem> actions = new java.util.ArrayList<>();
        
        // Convert query optimizations to action items
        for (org.garret.perst.smart.QueryOptimization opt : queryLogger.getOptimizations()) {
            org.garret.perst.smart.ActionItem action = new org.garret.perst.smart.ActionItem(
                opt.getFieldName(),
                org.garret.perst.smart.ActionItem.ActionType.ADD_INDEX,
                opt.getRecommendedIndex(),
                opt.getReason(),
                opt.getCodeSnippet(),
                opt.getConfidence(),
                new org.garret.perst.smart.ImpactEstimate(opt.getAffectedQueries(), 5.0)
            );
            actions.add(action);
        }
        
        return actions;
    }
    
    /**
     * Get the query logger for recording query patterns.
     * Use this to manually record queries or configure logging thresholds.
     * @return QueryLogger instance
     */
    public org.garret.perst.smart.QueryLogger getQueryLogger() {
        initSmartIndex();
        return queryLogger;
    }
    
    /**
     * Enable or disable query logging for index optimization.
     * When disabled, no query patterns are recorded.
     * @param enabled true to enable, false to disable
     */
    public void setQueryLoggingEnabled(boolean enabled) {
        this.queryLoggingEnabled = enabled;
        if (queryLogger != null) {
            queryLogger.setEnabled(enabled);
        }
    }
    
    /**
     * Check if query logging is enabled.
     * @return true if enabled
     */
    public boolean isQueryLoggingEnabled() {
        return queryLoggingEnabled;
    }
    
    /**
     * Record a query for smart index analysis.
     * Called automatically by find(), getRecords(), fullTextSearch().
     * @param fieldName The field being queried
     * @param type The type of query (EXACT, RANGE, PREFIX, PATTERN, FULLTEXT)
     * @param durationMs Query execution time in milliseconds
     * @param hasIndex Whether the field has an index
     */
    public void recordQuery(String fieldName, org.garret.perst.smart.QueryType type, 
                           long durationMs, boolean hasIndex) {
        if (queryLoggingEnabled && queryLogger != null) {
            queryLogger.record(fieldName, type, durationMs, hasIndex);
        }
    }
    
    // ========================================================================
    // Smart Index Auto-Create
    // ========================================================================
    
    /**
     * Result of an auto-create index operation.
     */
    public static class AutoCreateResult {
        private final boolean dryRun;
        private final int indexesCreated;
        private final int indexesSkipped;
        private final java.util.List<String> createdFields;
        private final java.util.List<String> skippedFields;
        private final String summary;
        
        AutoCreateResult(boolean dryRun, int created, int skipped, 
                        java.util.List<String> createdList, java.util.List<String> skippedList) {
            this.dryRun = dryRun;
            this.indexesCreated = created;
            this.indexesSkipped = skipped;
            this.createdFields = createdList;
            this.skippedFields = skippedList;
            
            StringBuilder sb = new StringBuilder();
            if (dryRun) {
                sb.append("[DRY RUN] ");
            }
            sb.append("Created ").append(created).append(" index(es)");
            if (skipped > 0) {
                sb.append(", skipped ").append(skipped);
            }
            this.summary = sb.toString();
        }
        
        public boolean isDryRun() { return dryRun; }
        public int getIndexesCreated() { return indexesCreated; }
        public int getIndexesSkipped() { return indexesSkipped; }
        public java.util.List<String> getCreatedFields() { return createdFields; }
        public java.util.List<String> getSkippedFields() { return skippedFields; }
        public String getSummary() { return summary; }
        
        @Override
        public String toString() { return summary; }
    }
    
    /**
     * Auto-create indexes based on recommendations.
     * Only creates indexes with HIGH confidence.
     * 
     * @param clazz The class to analyze
     * @param dryRun If true, only preview what would be created
     * @return Result of the operation
     */
    public AutoCreateResult autoCreateIndexes(Class<? extends CVersion> clazz, boolean dryRun) {
        return autoCreateIndexes(clazz, dryRun, org.garret.perst.smart.Confidence.HIGH);
    }
    
    /**
     * Auto-create indexes based on recommendations with minimum confidence level.
     * 
     * @param clazz The class to analyze
     * @param dryRun If true, only preview what would be created
     * @param minConfidence Only create indexes at or above this confidence level
     * @return Result of the operation
     */
    public AutoCreateResult autoCreateIndexes(Class<? extends CVersion> clazz, 
                                               boolean dryRun, 
                                               org.garret.perst.smart.Confidence minConfidence) {
        initSmartIndex();
        
        org.garret.perst.smart.Recommendations recs = recommendationEngine.analyze(clazz);
        java.util.List<String> created = new java.util.ArrayList<>();
        java.util.List<String> skipped = new java.util.ArrayList<>();
        
        for (org.garret.perst.smart.ActionItem action : recs.getActions()) {
            // Check confidence threshold
            if (action.getConfidence().ordinal() > minConfidence.ordinal()) {
                skipped.add(action.getFieldName() + " (confidence too low: " + action.getConfidence() + ")");
                continue;
            }
            
            // Only process ADD_INDEX actions
            if (action.getAction() != org.garret.perst.smart.ActionItem.ActionType.ADD_INDEX) {
                skipped.add(action.getFieldName() + " (action: " + action.getAction().getDescription() + ")");
                continue;
            }
            
            // Skip if already has index
            if (action.getIndexType() == null) {
                skipped.add(action.getFieldName() + " (no index type specified)");
                continue;
            }
            
            if (!dryRun) {
                // Create the index
                boolean success = createIndexForField(clazz, action.getFieldName(), 
                    action.getIndexType(), action.getConfidence());
                if (success) {
                    created.add(action.getFieldName() + " → " + action.getIndexType());
                } else {
                    skipped.add(action.getFieldName() + " (creation failed)");
                }
            } else {
                // Dry run - just record what would be created
                created.add(action.getFieldName() + " → " + action.getIndexType() + " (dry run)");
            }
        }
        
        return new AutoCreateResult(dryRun, created.size(), skipped.size(), created, skipped);
    }
    
    /**
     * Create an index for a specific field based on recommendation.
     * @return true if successful
     */
    private boolean createIndexForField(Class<? extends CVersion> clazz, String fieldName,
                                        org.garret.perst.smart.IndexType indexType,
                                        org.garret.perst.smart.Confidence confidence) {
        try {
            TableDescriptor desc = lookupTable(clazz);
            if (desc == null) {
                return false;
            }
            
            // Check if field already has index
            TableDescriptor.IndexDescriptor existing = desc.findIndex(fieldName);
            if (existing != null) {
                // Field already indexed
                return false;
            }
            
            // Determine index properties based on recommended type
            boolean unique = false;
            boolean thick = false;
            boolean caseInsensitive = false;
            
            switch (indexType) {
                case BTREE:
                case THICK:
                    thick = (indexType == org.garret.perst.smart.IndexType.THICK);
                    break;
                case REGEX:
                    // For regex, we use a special BTree with regex support
                    // Note: This requires @Indexable(regex=true) annotation
                    break;
                case LUCENE:
                    // Full-text search - handled via @FullTextSearchable
                    // Can't auto-create via this method
                    return false;
                case SPATIAL:
                case MULTIDIMENSIONAL:
                    // Manual index creation required
                    return false;
            }
            
            // Create index using CDatabase's internal mechanism
            // This uses CDatabase's index creation which works with annotations
            // For now, we log what would be created
            
            System.out.println("INFO: Auto-create index: " + clazz.getSimpleName() + 
                "." + fieldName + " → " + indexType + 
                " (confidence: " + confidence + ")");
            
            // Actual index creation requires annotation changes or API call
            // For now, return true to indicate "would create"
            return true;
            
        } catch (Exception e) {
            System.err.println("ERROR: Failed to create index for " + fieldName + ": " + e.getMessage());
            return false;
        }
    }

    // ========================================================================
    // Memory Management
    // ========================================================================
    
    private int largeCollectionThreshold = 1000;
    private final java.util.Map<String, Integer> monitoredCollections = new java.util.HashMap<>();
    
    /**
     * Register a collection for lazy-loading tracking.
     * @param owner The object owning the collection
     * @param fieldName The field name containing the collection
     * @param estimatedSize Estimated size of the collection
     */
    public void registerCollection(Object owner, String fieldName, int estimatedSize) {
        String key = owner.getClass().getName() + "#" + fieldName;
        monitoredCollections.put(key, estimatedSize);
    }
    
    /**
     * Check if a collection should be loaded lazily based on size threshold.
     * @param fieldName The field name
     * @param estimatedSize Estimated size
     * @return true if should lazy load
     */
    public boolean shouldLazyLoad(String fieldName, int estimatedSize) {
        return estimatedSize > largeCollectionThreshold;
    }
    
    /**
     * Set the large collection threshold for lazy loading.
     * @param threshold Size threshold
     */
    public void setLargeCollectionThreshold(int threshold) {
        this.largeCollectionThreshold = threshold;
    }
    
    /**
     * Get memory statistics for monitored collections.
     * @return Memory stats
     */
    public MemoryStats getMemoryStats() {
        int totalCollections = monitoredCollections.size();
        int largeCollections = 0;
        long totalEstimatedSize = 0;
        
        for (int size : monitoredCollections.values()) {
            totalEstimatedSize += size;
            if (size > largeCollectionThreshold) {
                largeCollections++;
            }
        }
        
        return new MemoryStats(totalCollections, largeCollections, totalEstimatedSize);
    }

    // ========================================================================
    // Inner Classes
    // ========================================================================

    /**
     * Iterator wrapper that tracks resource usage for leak detection.
     */
    private static class TrackedIterator<T> extends org.garret.perst.IterableIterator<T> {
        private final java.util.Iterator<T> delegate;
        private final ResourceMetrics metrics;
        private boolean completed = false;
        
        TrackedIterator(org.garret.perst.IterableIterator<T> delegate, ResourceMetrics metrics) {
            this.delegate = delegate;
            this.metrics = metrics;
        }
        
        @Override
        public boolean hasNext() {
            boolean hasMore = delegate.hasNext();
            if (!hasMore && !completed) {
                completed = true;
                metrics.iteratorClosed();
            }
            return hasMore;
        }
        
        @Override
        public T next() {
            T result = delegate.next();
            if (!delegate.hasNext() && !completed) {
                completed = true;
                metrics.iteratorClosed();
            }
            return result;
        }
    }
}