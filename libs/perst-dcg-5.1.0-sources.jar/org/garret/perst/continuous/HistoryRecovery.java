package org.garret.perst.continuous;

import org.apache.lucene.document.Document;
import org.garret.perst.Storage;

/**
 * Recovers history from single .trloca marker file.
 * 
 * On crash: if .trloca exists, rebuild from the encoded start point.
 */
public class HistoryRecovery {
    
    /**
     * Recovers history from .trloca marker if it exists.
     * 
     * @param storagePath Path to the storage (used to locate .trloca marker)
     * @param db The CDatabase instance to use for recovery
     */
    public static void recover(String storagePath, CDatabase db) {
        if (storagePath == null || db == null) {
            throw new IllegalArgumentException("Storage path and database cannot be null");
        }
        
        TransactionTracker tracker = new TransactionTracker(storagePath);
        
        try {
            if (!tracker.isRecoveryNeeded()) {
                return; // No recovery needed
            }
            
            TransactionTracker.TransactionEntry entry = tracker.parseMarker();
            if (entry == null) {
                return;
            }
            
            // Replay from the start point
            replayTransaction(entry, db);
            
            // Clear marker after successful recovery
            tracker.clearMarker();
            
        } finally {
            tracker.shutdown();
        }
    }
    
    private static void replayTransaction(TransactionTracker.TransactionEntry entry, CDatabase db) {
        try {
            Storage storage = db.getStorage();
            Object obj = storage.getObjectByOID(entry.objectId);
            
            if (obj instanceof CVersion) {
                CVersion version = (CVersion) obj;
                TableDescriptor desc = db.getTable(version.getClass());
                Document historyDoc = desc.buildDocument(version);
                if (historyDoc != null) {
                    db.addToHistoryBuffer(historyDoc);
                }
            }
        } catch (Exception e) {
            System.err.println("Failed to replay transaction " + entry.transId + 
                             " for object " + entry.objectId + ": " + e.getMessage());
        }
    }
}
