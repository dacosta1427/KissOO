package org.garret.perst.continuous;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Single .trloca marker file for crash recovery.
 * 
 * Filename format: {transId}_{objectId}_{operation}.trloca
 * Example: 1_1001_INSERT.trloca
 * 
 * Lifecycle:
 * 1. New objects committed → if NO .trloca exists, CREATE it
 * 2. Buffer fills up → if .trloca exists, do nothing
 * 3. Buffer flushes to Lex → .trloca DELETED after flush AND buffer empty
 * 4. Crash during filling → .trloca EXISTS → rebuild from that point
 * 5. Crash after flush → NO .trloca → normal startup
 */
public class TransactionTracker {
    
    private final String basePath;
    private final ExecutorService executor;
    
    public TransactionTracker(String basePath) {
        this.basePath = basePath.endsWith(File.separator) ? basePath : basePath + File.separator;
        this.executor = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "TransactionTracker");
            t.setDaemon(true);
            return t;
        });
    }
    
    /**
     * Creates marker file if it doesn't exist.
     * File is named: {transId}_{objectId}_{operation}.trloca
     */
    public void markIfAbsent(long transId, int objectId, String operation) {
        executor.submit(() -> {
            if (!isRecoveryNeeded()) {
                String filename = String.format("%d_%d_%s.trloca", transId, objectId, operation);
                File markerFile = new File(basePath + filename);
                try {
                    markerFile.createNewFile();
                } catch (IOException e) {
                    System.err.println("Failed to create .trloca: " + e.getMessage());
                }
            }
        });
    }
    
    /**
     * Checks if marker exists (recovery needed).
     */
    public boolean isRecoveryNeeded() {
        File dir = new File(basePath);
        File[] files = dir.listFiles((d, name) -> name.endsWith(".trloca"));
        return files != null && files.length > 0;
    }
    
    /**
     * Parses marker filename to get recovery start point.
     */
    public TransactionEntry parseMarker() {
        File dir = new File(basePath);
        File[] files = dir.listFiles((d, name) -> name.endsWith(".trloca"));
        if (files == null || files.length == 0) {
            return null;
        }
        return parseFilename(files[0].getName());
    }
    
    /**
     * Deletes marker after successful recovery/flush.
     */
    public void clearMarker() {
        File dir = new File(basePath);
        File[] files = dir.listFiles((d, name) -> name.endsWith(".trloca"));
        if (files != null) {
            for (File f : files) {
                f.delete();
            }
        }
    }
    
    private TransactionEntry parseFilename(String filename) {
        String name = filename.replace(".trloca", "");
        String[] parts = name.split("_");
        if (parts.length >= 3) {
            try {
                return new TransactionEntry(
                    Long.parseLong(parts[0]),
                    Integer.parseInt(parts[1]),
                    parts[2]
                );
            } catch (NumberFormatException e) {
                return null;
            }
        }
        return null;
    }
    
    public void shutdown() {
        executor.shutdown();
        try {
            if (!executor.awaitTermination(5, TimeUnit.SECONDS)) {
                executor.shutdownNow();
            }
        } catch (InterruptedException e) {
            executor.shutdownNow();
        }
    }
    
    public static class TransactionEntry {
        public final long transId;
        public final int objectId;
        public final String operation;
        
        public TransactionEntry(long transId, int objectId, String operation) {
            this.transId = transId;
            this.objectId = objectId;
            this.operation = operation;
        }
    }
}
