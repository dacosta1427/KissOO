package org.garret.perst.annotations;

import java.lang.annotation.*;

/**
 * Exclude field from JSON serialization/deserialization entirely.
 * 
 * Usage:
 * <pre>
 * public class House extends CVersion {
 *     private String name;           // Included in JSON
 *     
 *     &#064;JsonIgnore
 *     private String internalNotes;  // Excluded from JSON
 * }
 * </pre>
 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface JsonIgnore {
}
