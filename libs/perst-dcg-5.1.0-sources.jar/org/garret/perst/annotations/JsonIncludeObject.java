package org.garret.perst.annotations;

import java.lang.annotation.*;

/**
 * Serialize referenced CVersion objects inline instead of as OID.
 * 
 * Behavior:
 * <ul>
 *   <li>For fields of type CVersion: serialize the entire object inline</li>
 *   <li>For fields of type Collection&lt;CVersion&gt;: serialize array of objects (not OIDs)</li>
 * </ul>
 * 
 * Default behavior (without this annotation):
 * <ul>
 *   <li>CVersion references: serialized as OID (long)</li>
 *   <li>Collections of CVersion: serialized as array of OIDs</li>
 * </ul>
 * 
 * Usage:
 * <pre>
 * public class House extends CVersion {
 *     private Owner owner;                    // Serialized as: "owner": 4242 (OID)
 *     
 *     &#064;JsonIncludeObject
 *     private CostProfile costProfile;        // Serialized inline as object
 *     
 *     private List&lt;Booking&gt; bookings;         // Serialized as [oid1, oid2, ...]
 *     
 *     &#064;JsonIncludeObject
 *     private List&lt;Room&gt; rooms;               // Serialized as [{...}, {...}, ...]
 * }
 * </pre>
 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface JsonIncludeObject {
}
