package org.garret.perst;

import java.util.*;
import java.io.StringReader;
import java.lang.reflect.*;
import org.garret.perst.fulltext.*;
import org.garret.perst.impl.ClassDescriptor;

/**
 * This class emulates relational database on top of Perst storage
 * It maintain class extends, associated indices, prepare queries.
 */
@SuppressWarnings({"rawtypes", "unchecked"})
public class Database implements IndexProvider { 
    /** 
     * Constructor of database. This method initialize database if it not initialized yet.
     * Starting from 2.72 version of Perst.Net, it supports automatic
     * creation of table descriptors when Database class is used.
     * So now it is not necessary to explicitly create tables and indices -
     * the Database class will create them itself on demand.
     * Indexable attribute should be used to mark key fields for which index should be created.
     * Table descriptor is created when instance of the correspondent class is first time stored 
     * in the database. Perst creates table descriptors for all derived classes up
     * to the root java.lang.Object class.
     * @param storage opened storage. Storage should be either empty (non-initialized, either
     * previously initialized by the this method. It is not possible to open storage with 
     * root object other than table index created by this constructor.
     * @param multithreaded <code>true</code> if database should support concurrent access
     * to the data from multiple threads.
     */
    public Database(Storage storage, boolean multithreaded) { 
        this(storage, multithreaded, true, null);
    }

    /** 
     * Constructor of database. This method initialize database if it not initialized yet.
     * @param storage opened storage. Storage should be either empty (non-initialized, either
     * previously initialized by the this method. It is not possible to open storage with 
     * root object other than table index created by this constructor.
     * @param multithreaded <code>true</code> if database should support concurrent access
     * to the data from multiple threads.
     * @param autoRegisterTables automatically create tables descriptors for instances of new 
     * @param helper helper for full text index
     * classes inserted in the database
     */
    public Database(Storage storage, boolean multithreaded, boolean autoRegisterTables, FullTextSearchHelper helper) { 
        this.storage = storage;
        this.multithreaded = multithreaded;
        this.autoRegisterTables = autoRegisterTables;
        this.searchBaseClasses = !autoRegisterTables && !Boolean.FALSE.equals(storage.getProperty("perst.search.base.classes"));
        this.globalClassExtent = !Boolean.FALSE.equals(storage.getProperty("perst.global.class.extent"));
        if (multithreaded) { 
            storage.setProperty("perst.alternative.btree", Boolean.TRUE);
        }
        storage.setProperty("perst.concurrent.iterator", Boolean.TRUE);
        Object root = storage.getRoot();
        boolean schemaUpdated = false;
        if (root instanceof Index) { // backward compatibility
            beginTransaction();
            metadata = new Metadata(storage, (Index)root, helper);
            storage.setRoot(metadata);
            schemaUpdated = true;
        } else if (root == null) {
            beginTransaction();
            metadata = new Metadata(storage, helper);
            storage.setRoot(metadata);
            schemaUpdated = true;
        } else { 
            metadata = (Metadata)root;
        }
        schemaUpdated |= reloadSchema();
        if (schemaUpdated) {
            commitTransaction();
        }
    }

    @SuppressWarnings("unchecked")
    private boolean reloadSchema() 
    {
        boolean schemaUpdated = false;
        metadata = (Metadata)storage.getRoot();
        Iterator<Map.Entry<Object, Table>> iterator = metadata.metaclasses.entryIterator();
        tables = new HashMap<>();
        while (iterator.hasNext()) { 
            Map.Entry<Object, Table> map = iterator.next();
            Table table = map.getValue();
            Class cls = ClassDescriptor.loadClass(storage, (String)map.getKey());
            table.setClass(cls);
            tables.put(cls, table);
            schemaUpdated |= addIndices(table, cls);
        }
        return schemaUpdated;
    }
        
    /** 
     * Constructor of single threaded database. This method initialize database if it not initialized yet.
     * @param storage opened storage. Storage should be either empty (non-initialized, either
     * previously initialized by the this method. It is not possible to open storage with 
     * root object other than table index created by this constructor.
     */
    public Database(Storage storage) { 
        this(storage, false);
    }

    /** 
     * Tells whether or not this database is opened in multithreaded mode
     */
    public boolean isMultithreaded() { 
        return multithreaded; 
    }

    /**
     * Enable or disable automatic creation of indices. 
     * If this feature is enabled, Perst will try to create new index each time when it needs it during
     * query execution
     * @param enabled if true, then automatic creation of indices is enabled
     * @return previous status
     */
    public boolean enableAutoIndices(boolean enabled) { 
        boolean prev = autoIndices;
        autoIndices = enabled;
        return prev;
    }
        
    /**
     * Begin transaction
     */
    public void beginTransaction() { 
        if (multithreaded) { 
            storage.beginSerializableTransaction();
        }
    }

    /**
     * Commit transaction
     */
    public void commitTransaction() { 
        if (multithreaded) { 
            storage.commitSerializableTransaction();
        } else { 
            storage.commit();
        }
    }
    
    /**
     * Rollback transaction
     */
    public void rollbackTransaction() { 
        if (multithreaded) { 
            storage.rollbackSerializableTransaction();
        } else { 
            storage.rollback();
        }
        reloadSchema();
    }
    
    private void checkTransaction() {
        if (!storage.isInsideThreadTransaction()) { 
            throw new StorageError(StorageError.NOT_IN_TRANSACTION);
        }
    }

    private boolean addIndices(Table table, Class cls) {
        boolean schemaUpdated = false;
        for (Field f : cls.getDeclaredFields()) { 
            Indexable idx = (Indexable)f.getAnnotation(Indexable.class);
            if (idx != null) { 
                int kind = INDEX_KIND_DEFAULT;
                if (idx.unique()) kind |= INDEX_KIND_UNIQUE;
                if (idx.caseInsensitive()) kind |= INDEX_KIND_CASE_INSENSITIVE;
                if (idx.thick()) kind |= INDEX_KIND_THICK;
                if (idx.randomAccess()) kind |= INDEX_KIND_RANDOM_ACCESS;
                if (idx.regex()) kind |= INDEX_KIND_REGEX; 
                schemaUpdated |= createIndex(table, cls, f.getName(), kind);
                if (idx.autoincrement()) { 
                    if (table.autoincrementIndex != null) { 
                        throw new UnsupportedOperationException("Table can have only one autoincrement field");
                    } 
                    table.autoincrementIndex = (FieldIndex)table.indicesMap.get(f.getName());
                }                    
            }            
        }
        return schemaUpdated;
    }

    /**
     * Drop table associated with this class. Do nothing if there is no such table in the database.
     * @param table class corresponding to the table
     * @return <code>true</code> if table is deleted, <code>false</code> if table 
     * is not found
     */
    public boolean dropTable(Class table) { 
        if (multithreaded) { 
            checkTransaction();
            metadata.exclusiveLock();
        }
        Table t = tables.remove(table);
        if (t != null) { 
            boolean savePolicy = storage.setRecursiveLoading(table, false);            
            for (Object obj : t.extent) { 
                if (obj instanceof FullTextSearchable || t.fullTextIndexableFields.size() != 0) { 
                    metadata.fullTextIndex.delete(obj);
                }
                for (Class baseClass = table; (baseClass = baseClass.getSuperclass()) != null;)  {
                    Table baseTable = (Table)tables.get(baseClass);
                    if (baseTable != null) { 
                        if (multithreaded) { 
                            baseTable.extent.exclusiveLock();
                        }
                        if (baseTable.extent.remove(obj)) { 
                            Iterator iterator = baseTable.indicesMap.values().iterator();
                            while (iterator.hasNext()) { 
                                FieldIndex index = (FieldIndex)iterator.next();
                                index.remove(obj);
                            }
                        }
                    }
                }    
                storage.deallocate(obj);
            }
            metadata.metaclasses.remove(table.getName());
            t.deallocate();
            storage.setRecursiveLoading(table, savePolicy);
            return true;
        }
        return false;
    }
        
    /**
     * Add new record to the table. Record is inserted in table corresponding to the class of the object.
     * Record will be automatically added to all indices existed for this table.
     * If there is no table associated with class of this object, then 
     * database will search for table associated with superclass and so on...
     * @param record object to be inserted in the table
     * @return <code>true</code> if record was successfully added to the table, <code>false</code>
     * if there is already such record (object with the same ID) in the table or there is some record with the same value of 
     * unique key field
     * @exception StorageError (CLASS_NOT_FOUND) exception is thrown if there is no table corresponding to 
     * record class
     */
    public <T> boolean addRecord(T record) { 
        return addRecord(record.getClass(), record);        
    }

    private Table locateTable(Class cls, boolean exclusive) { 
        return locateTable(cls, exclusive, true);
    }

    private Table locateTable(Class cls, boolean exclusive, boolean shouldExist) { 
        Table table = null;
        if (multithreaded) { 
            checkTransaction();
            metadata.sharedLock();
        }
        if (searchBaseClasses) { 
            for (Class c = cls; c != null && (table = tables.get(c)) == null; c = c.getSuperclass());
        } else { 
            table = tables.get(cls);
        }
        if (table == null) { 
            if (shouldExist) { 
                throw new StorageError(StorageError.CLASS_NOT_FOUND, cls.getName());
            }
            return null;
        }
        if (multithreaded) { 
            if (exclusive) { 
                table.extent.exclusiveLock();
            } else { 
                table.extent.sharedLock();
            }
        }
        return table;
    }

    private void registerTable(Class cls) { 
        if (multithreaded) { 
            checkTransaction();
            metadata.sharedLock();
        }
        if (autoRegisterTables) { 
            boolean exclusiveLockSet = false;           
            for (Class c = cls; c != Object.class; c = c.getSuperclass()) { 
                Table t = tables.get(c);
                if (t == null && c != PinnedPersistent.class && (globalClassExtent || c != Persistent.class)) { 
                    if (multithreaded && !exclusiveLockSet) { 
                        metadata.unlock(); // try to avoid deadlock caused by concurrent insertion of objects
                        exclusiveLockSet = true;
                    }
                    createTableInternal(c);
                }
            }
        }
    }
    
    private void createTableInternal(Class table) { 
        if (multithreaded) { 
            checkTransaction();
            metadata.exclusiveLock();
        }
        if (tables.get(table) == null) { 
            Table t = new Table();
            t.extent = storage.createSet();
            t.indices = storage.createLink();
            t.indicesMap = new HashMap<String, FieldIndex>();
            t.setClass(table);
            tables.put(table, t);
            metadata.metaclasses.put(table.getName(), t);
            addIndices(t, table);
        }
    }
        
    /**
     * Update full text index for modified record
     * @param record updated record
     */
    public <T> void updateFullTextIndex(T record) 
    { 
        if (multithreaded) { 
            checkTransaction();
            metadata.fullTextIndex.exclusiveLock();
        }
        if (record instanceof FullTextSearchable) { 
            metadata.fullTextIndex.add((FullTextSearchable)record);
        } else { 
            StringBuffer fullText = new StringBuffer();
            for (Class c = record.getClass(); c != null; c = c.getSuperclass()) { 
                Table t = tables.get(c);
                if (t != null) { 
                    for (Field f : t.fullTextIndexableFields) { 
                        Object text;
                        try { 
                            text = f.get(record);
                        } catch (IllegalAccessException x) { 
                                throw new IllegalAccessError();            
                        }
                        if (text != null) { 
                            fullText.append(' ');
                            fullText.append(text.toString());
                        }
                    }
                }
            }
            metadata.fullTextIndex.add(record, new StringReader(fullText.toString()), null);
        }
    }

    /**
     * Add new record to the specified table. Record is inserted in table corresponding to the specified class.
     * Record will be automatically added to all indices existed for this table.
     * @param table class corresponding to the table
     * @param record object to be inserted in the table
     * @return <code>true</code> if record was successfully added to the table, <code>false</code>
     * if there is already such record (object with the same ID) in the table or there is some record with the same value of 
     * unique key field
     * @exception StorageError (CLASS_NOT_FOUND) exception is thrown if there is no table corresponding to 
     * record class
     */
    @SuppressWarnings("unchecked")
    public <T> boolean addRecord(Class table, T record) { 
        boolean added = false;
        boolean found = false;
        registerTable(table);
        ArrayList wasInsertedIn = new ArrayList();
        StringBuffer fullText = new StringBuffer();
        for (Class c = table; c != null; c = c.getSuperclass()) { 
            Table t = tables.get(c);
            if (t != null) { 
                found = true;
                if (multithreaded) { 
                    t.extent.exclusiveLock();
                }
                if (t.extent.add(record)) { 
                    wasInsertedIn.add(t.extent);
                    Iterator iterator = t.indicesMap.values().iterator();
                    while (iterator.hasNext()) { 
                        FieldIndex index = (FieldIndex)iterator.next();
                        if (index == t.autoincrementIndex) { 
                            index.append(record);
                            storage.modify(record);
                            wasInsertedIn.add(index);
                        } else if (index.put(record)) {
                            wasInsertedIn.add(index);
                        } else if (index.isUnique()) { 
                            iterator = wasInsertedIn.iterator();
                            while (iterator.hasNext()) { 
                                Object idx = iterator.next();
                                if (idx instanceof IPersistentSet) {
                                    ((IPersistentSet)idx).remove(record);
                                } else { 
                                    ((FieldIndex)idx).remove(record);
                                }
                            }
                            return false;
                        }
                    }
                    for (Field f : t.fullTextIndexableFields) { 
                        Object text;
                        try { 
                            text = f.get(record);
                        } catch (IllegalAccessException x) { 
                            throw new IllegalAccessError();            
                        }
                        if (text != null) { 
                            fullText.append(' ');
                            fullText.append(text.toString());
                        }
                    }
                    added = true;
                }
            }
        }
        if (!found) { 
            throw new StorageError(StorageError.CLASS_NOT_FOUND, table.getName());
        }      
        if (record instanceof FullTextSearchable || fullText.length() != 0) { 
            if (multithreaded) { 
                metadata.fullTextIndex.exclusiveLock();
            }
            if (record instanceof FullTextSearchable) { 
                metadata.fullTextIndex.add((FullTextSearchable)record);
            } else { 
                metadata.fullTextIndex.add(record, new StringReader(fullText.toString()), null);
            }
        }
        return added;
    }
        
    /** 
     * Delete record from the table. Record is removed from the table corresponding to the class 
     * of the object. Record will be automatically added to all indices existed for this table.
     * If there is no table associated with class of this object, then 
     * database will search for table associated with superclass and so on...
     * Object represented the record will be also deleted from the storage.
     * @param record object to be deleted from the table
     * @return <code>true</code> if record was successfully deleted from the table, <code>false</code>
     * if there is not such record (object with the same ID) in the table
     * @exception StorageError (CLASS_NOT_FOUND) exception is thrown if there is no table corresponding to 
     * record class
     */
    public <T> boolean deleteRecord(T record) { 
        return deleteRecord(record.getClass(), record);
    }

    /** 
     * Delete record from the specified table. Record is removed from the table corresponding to the 
     * specified class. Record will be automatically added to all indices existed for this table.
     * Object represented the record will be also deleted from the storage.
     * @param table class corresponding to the table
     * @param record object to be deleted from the table
     * @return <code>true</code> if record was successfully deleted from the table, <code>false</code>
     * if there is not such record (object with the same ID) in the table
     * @exception StorageError (CLASS_NOT_FOUND) exception is thrown if there is no table corresponding to 
     * specified class
     */
    public <T> boolean deleteRecord(Class table, T record) { 
        boolean removed = false;
        if (multithreaded) { 
            checkTransaction();
            metadata.sharedLock();
        }
        boolean fullTextIndexed = false;
        for (Class c = table; c != null; c = c.getSuperclass()) { 
            Table t = tables.get(c);
            if (t != null) { 
                if (multithreaded) { 
                    t.extent.exclusiveLock();
                }
                if (t.extent.remove(record)) { 
                    Iterator iterator = t.indicesMap.values().iterator();
                    while (iterator.hasNext()) { 
                        FieldIndex index = (FieldIndex)iterator.next();
                        index.remove(record);
                    }
                    if (!t.fullTextIndexableFields.isEmpty()) { 
                        fullTextIndexed = true;
                    }
                    removed = true;
                }
            }
        }
        if (removed) {
            if (record instanceof FullTextSearchable || fullTextIndexed) {
                if (multithreaded) { 
                    metadata.fullTextIndex.exclusiveLock();
                }
                metadata.fullTextIndex.delete(record);
            }
            storage.deallocate(record);
        }
        return removed;
    }

    public static final int INDEX_KIND_DEFAULT = 0;
    public static final int INDEX_KIND_UNIQUE = 1;
    public static final int INDEX_KIND_REGEX = 2;
    public static final int INDEX_KIND_THICK = 4;
    public static final int INDEX_KIND_RANDOM_ACCESS = 8;
    public static final int INDEX_KIND_CASE_INSENSITIVE = 16;

    private boolean createIndex(Table t, Class c, String key, int kind) {
        if (t.indicesMap.get(key) == null) { 
            boolean unique = (kind & INDEX_KIND_UNIQUE) != 0;
            boolean caseInsensitive = (kind & INDEX_KIND_CASE_INSENSITIVE) != 0;
            FieldIndex index = (kind & INDEX_KIND_REGEX) != 0
                ? storage.createRegexIndex(c, key, caseInsensitive, 3)
                : (kind & INDEX_KIND_RANDOM_ACCESS) != 0
                    ? storage.createRandomAccessFieldIndex(c, key, unique, caseInsensitive)
                    : storage.createFieldIndex(c, key, unique, caseInsensitive, (kind & INDEX_KIND_THICK) != 0);
            t.indicesMap.put(key, index);
            t.indices.add(index);
            for (Object obj : t.extent) { 
                if (!index.put(obj) && unique) { 
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    /**
     * Add new index to the table. If such index already exists this method does nothing.
     * @param t table to add index to
     * @param c class corresponding to the table
     * @param key field of the class to be indexed
     * @param kind bitmask of index kind flags
     * @exception StorageError (CLASS_NOT_FOUND) exception is thrown if there is no table corresponding to 
     * the specified class
     * @return <code>true</code> if index is created, <code>false</code> if index
     * already exists
     */

    /**
     * Drop index for the specified table and key.
     * Does nothing if there is no such index.
     * @param table class corresponding to the table
     * @param key field of the class to be indexed
     * @exception StorageError (CLASS_NOT_FOUND) exception is thrown if there is no table corresponding to 
     * the specified class
     * @return <code>true</code> if index is deleted, <code>false</code> if index 
     * is not found
     */
    public boolean dropIndex(Class table, String key) { 
        Table t = locateTable(table, true);
        FieldIndex index = (FieldIndex)t.indicesMap.remove(key);
        if (index != null) { 
            t.indices.remove(t.indices.indexOf(index));
            return true;
        }
        return false;
    }

    /**
     * Get index for the specified field of the class
     * @param table class where index is located
     * @param key field of the class
     * @return Index for this field or null if index doesn't exist
     */
    public GenericIndex getIndex(Class table, String key)
    {
        for (Class c = table; c != null; c = c.getSuperclass()) { 
            Table t = locateTable(c, false, false);
            if (t != null) { 
                synchronized (t.indicesMap) { 
                    GenericIndex index = (GenericIndex)t.indicesMap.get(key);
                    if (index != null) { 
                        return index;
                    }
                    if (autoIndices && key.indexOf('.') < 0) {
                        try { 
                            c.getDeclaredField(key);
                        } catch (NoSuchFieldException x) { 
                            continue;
                        }
                        StorageListener listener = storage.getListener();
                        if (listener != null) { 
                            listener.indexCreated(c, key);
                        }
                        createIndex(t, c, key, INDEX_KIND_DEFAULT); 
                        return (GenericIndex)t.indicesMap.get(key);
                    }
                }
            }
        }
        return null;
    }

    /**
     * Get indices for the specified table
     * @param table class corresponding to the table
     * @return map of table indices
     */
    public HashMap<String, FieldIndex> getIndices(Class table)
    {
        Table t = locateTable(table, true, false);
        return t == null ? new HashMap<String, FieldIndex>() : t.indicesMap;
    }

    /**
     * Exclude record from all indices. This method is needed to perform update of indexed
     * field (key). Before updating the record, it is necessary to exclude it from indices
     * which keys are affected. After updating the field, record should be reinserted in these indices
     * using includeInIndex method. If your know which fields will be updated and which indices
     * exist for this table, it is more efficient to use excludeFromIndex method to exclude
     * object only from affected indices.<P>
     * @param record object to be excluded from the specified index
     * @exception StorageError (CLASS_NOT_FOUND) exception is thrown if there is no table corresponding to 
     * record class
     */
    public void excludeFromAllIndices(Object record) {
        excludeFromAllIndices(record.getClass(), record);
    }

    /**
     * Exclude record from all indices. This method is needed to perform update of indexed
     * field (key). Before updating the record, it is necessary to exclude it from indices
     * which keys are affected. After updating the field, record should be reinserted in these indices
     * using includeInIndex method. If your know which fields will be updated and which indices
     * exist for this table, it is more efficient to use excludeFromIndex method to exclude
     * object only from affected indices.<P>
     * @param table class corresponding to the table
     * @param record object to be excluded from the specified index
     * @exception StorageError (CLASS_NOT_FOUND) exception is thrown if there is no table corresponding to 
     * record class
     */
    public void excludeFromAllIndices(Class table, Object record) {
        if (multithreaded) { 
            checkTransaction();
            metadata.sharedLock();
        }
        boolean fullTextIndexed = false;
        for (Class c = table; c != null; c = c.getSuperclass()) { 
            Table t = tables.get(c);
            if (t != null) { 
                if (multithreaded) { 
                    t.extent.exclusiveLock();
                }
                Iterator iterator = t.indicesMap.values().iterator();
                while (iterator.hasNext()) { 
                    FieldIndex index = (FieldIndex)iterator.next();
                    index.remove(record);
                }
                if (!t.fullTextIndexableFields.isEmpty()) { 
                    fullTextIndexed = true;
                }
            }
        }
        if (record instanceof FullTextSearchable || fullTextIndexed) {
            if (multithreaded) { 
                metadata.fullTextIndex.exclusiveLock();
            }
            metadata.fullTextIndex.delete(record);
        }
    }

    /**
     * Exclude record from specified index. This method is needed to perform update of indexed
     * field (key). Before updating the record, it is necessary to exclude it from indices
     * which keys are affected. After updating the field, record should be reinserted in these indices
     * using includeInIndex method.<P>
     * If there is no table associated with class of this object, then 
     * database will search for table associated with superclass and so on...<P>
     * This method does nothing if there is no index for the specified field.
     * @param record object to be excluded from the specified index
     * @param key name of the indexed field
     * @exception StorageError (CLASS_NOT_FOUND) exception is thrown if there is no table corresponding to 
     * record class
     * @return <code>true</code> if record is excluded from index, <code>false</code> if 
     * there is no such index
     */
    public boolean excludeFromIndex(Object record, String key) {
        return excludeFromIndex(record.getClass(), record, key);
    }

    /**
     * Exclude record from specified index. This method is needed to perform update of indexed
     * field (key). Before updating the record, it is necessary to exclude it from indices
     * which keys are affected. After updating the field, record should be reinserted in these indices
     * using includeInIndex method.<P>
     * If there is no table associated with class of this object, then 
     * database will search for table associated with superclass and so on...<P>
     * This method does nothing if there is no index for the specified field.
     * @param table class corresponding to the table
     * @param record object to be excluded from the specified index
     * @param key name of the indexed field
     * @exception StorageError (CLASS_NOT_FOUND) exception is thrown if there is no table corresponding to 
     * the specified class
     * @return <code>true</code> if record is excluded from index, <code>false</code> if 
     * there is no such index
     */
    public boolean excludeFromIndex(Class table, Object record, String key) {
        Table t = locateTable(table, true);
        FieldIndex index = (FieldIndex)t.indicesMap.get(key);
        if (index != null) { 
            index.remove(record);
            return true;
        }
        return false;
    }


    /**
     * Include record in all indices. This method is needed to perform update of indexed
     * fields (keys). Before updating the record, it is necessary to exclude it from indices
     * which keys are affected using excludeFromIndices method. After updating the field, record should be 
     * reinserted in these indices using this method. If your know which fields will be updated and which indices
     * exist for this table, it is more efficient to use excludeFromIndex/includeInIndex methods to touch
     * only affected indices.
     * @param record object to be excluded from the specified index
     * @exception StorageError (CLASS_NOT_FOUND) exception is thrown if there is no table corresponding to 
     * the specified class
     * @return <code>true</code> if record is included in indices, <code>false</code> if 
     * there is no such index or unique constraint is violated
     */
    public boolean includeInAllIndices(Object record) { 
        return includeInAllIndices(record.getClass(), record);
    }

    /**
     * Include record in all indices. This method is needed to perform update of indexed
     * fields (keys). Before updating the record, it is necessary to exclude it from indices
     * which keys are affected using excludeFromIndices method. After updating the field, record should be 
     * reinserted in these indices using this method. If your know which fields will be updated and which indices
     * exist for this table, it is more efficient to use excludeFromIndex/includeInIndex methods to touch
     * only affected indices.
     * @param table class corresponding to the table
     * @param record object to be excluded from the specified index
     * @return <code>true</code> if record is included in index, <code>false</code> if 
     * there is no such index or unique constraint is violated
     * @exception StorageError (CLASS_NOT_FOUND) exception is thrown if there is no table corresponding to 
     * the specified class
     * @return <code>true</code> if record is included in index, <code>false</code> if 
     * there is no such index or unique constraint is violated
     */
    @SuppressWarnings("unchecked")
    public boolean includeInAllIndices(Class table, Object record) { 
        if (multithreaded) { 
            checkTransaction();
        }
        ArrayList wasInsertedIn = new ArrayList();
        StringBuffer fullText = new StringBuffer();
        for (Class c = table; c != null; c = c.getSuperclass()) { 
            Table t = tables.get(c);
            if (t != null) { 
                if (multithreaded) { 
                    t.extent.exclusiveLock();
                }
                Iterator iterator = t.indicesMap.values().iterator();
                while (iterator.hasNext()) { 
                    FieldIndex index = (FieldIndex)iterator.next();
                    if (index.put(record)) {
                        wasInsertedIn.add(index);
                    } else if (index.isUnique()) { 
                        iterator = wasInsertedIn.iterator();
                        while (iterator.hasNext()) { 
                            Object idx = iterator.next();
                            if (idx instanceof IPersistentSet) {
                                ((IPersistentSet)idx).remove(record);
                            } else { 
                                ((FieldIndex)idx).remove(record);
                            }
                        }
                        return false;
                    }
                }
                for (Field f : t.fullTextIndexableFields) { 
                    Object text;
                    try { 
                        text = f.get(record);
                    } catch (IllegalAccessException x) { 
                        throw new IllegalAccessError();            
                    }
                    if (text != null) { 
                        fullText.append(' ');
                        fullText.append(text.toString());
                    }
                }
            }
        }
        if (record instanceof FullTextSearchable || fullText.length() != 0) { 
            if (multithreaded) { 
                metadata.fullTextIndex.exclusiveLock();
            }
            if (record instanceof FullTextSearchable) { 
                metadata.fullTextIndex.add((FullTextSearchable)record);
            } else { 
                metadata.fullTextIndex.add(record, new StringReader(fullText.toString()), null);
            }
        }
        return true;
    }


    /**
     * Include record in the specified index. This method is needed to perform update of indexed
     * field (key). Before updating the record, it is necessary to exclude it from indices
     * which keys are affected using excludeFromIndex method. After updating the field, record should be 
     * reinserted in these indices using this method.<P>
     * If there is no table associated with class of this object, then 
     * database will search for table associated with superclass and so on...<P>
     * This method does nothing if there is no index for the specified field.
     * @param record object to be excluded from the specified index
     * @param key name of the indexed field
     * @exception StorageError (CLASS_NOT_FOUND) exception is thrown if there is no table corresponding to 
     * the specified class
     * @return <code>true</code> if record is included in index, <code>false</code> if 
     * there is no such index or unique constraint is violated
     */
    public boolean includeInIndex(Object record, String key) { 
        return includeInIndex(record.getClass(), record, key);
    }

    /**
     * Include record in the specified index. This method is needed to perform update of indexed
     * field (key). Before updating the record, it is necessary to exclude it from indices
     * which keys are affected using excludeFromIndex method. After updating the field, record should be 
     * reinserted in these indices using this method.<P>
     * If there is no table associated with class of this object, then 
     * database will search for table associated with superclass and so on...<P>
     * This method does nothing if there is no index for the specified field.
     * @param table class corresponding to the table
     * @param record object to be excluded from the specified index
     * @param key name of the indexed field
     * @exception StorageError (CLASS_NOT_FOUND) exception is thrown if there is no table corresponding to 
     * the specified class
     * @return <code>true</code> if record is included in index, <code>false</code> if 
     * there is no such index or unique constraint is violated
     */
    @SuppressWarnings("unchecked")
    public boolean includeInIndex(Class table, Object record, String key) { 
        Table t = locateTable(table, true);
        FieldIndex index = (FieldIndex)t.indicesMap.get(key);
        if (index != null) { 
            return index.put(record) || !index.isUnique();
        }
        return false;
    }

    /**
     * This method can be used to update a key field. It is responsibility of programmer in Perst
     * to maintain consistency of indices: before updating key field it is necessary to exclude 
     * the object from the index and after assigning new value to the key field - reinsert it in the index.
     * It can be done using excludeFromIndex/includeInIndex methods, but updateKey combines all this steps:
     * exclude from index, update, mark object as been modified and reinsert in index.
     * It is safe to call updateKey method for fields which are actually not used in any index - 
     * in this case excludeFromIndex/includeInIndex do nothing.
     * @param record updated object
     * @param key name of the indexed field
     * @param value new value of indexed field
     * @exception StorageError (INDEXED_FIELD_NOT_FOUND) exception is thrown if specified field is not found in 
     * @exception StorageError (ACCESS_VIOLATION) exception is thrown if it is not possible to change field value
     */ 
    public void updateKey(Object record, String key, Object value) {
        updateKey(record.getClass(), record, key, value);
    }
            

    /**
     * This method can be used to update a key field. It is responsibility of programmer in Perst
     * to maintain consistency of indices: before updating key field it is necessary to exclude 
     * the object from the index and after assigning new value to the key field - reinsert it in the index.
     * It can be done using excludeFromIndex/includeInIndex methods, but updateKey combines all this steps:
     * exclude from index, update, mark object as been modified and reinsert in index.
     * It is safe to call updateKey method for fields which are actually not used in any index - 
     * in this case excludeFromIndex/includeInIndex do nothing.
     * @param table class corresponding to the table
     * @param record updated object
     * @param key name of the indexed field
     * @param value new value of indexed field
     * @exception StorageError (INDEXED_FIELD_NOT_FOUND) exception is thrown if specified field is not found in the class
     * @exception StorageError (ACCESS_VIOLATION) exception is thrown if it is not possible to change field value
     */ 
    public void updateKey(Class table, Object record, String key, Object value) {
        excludeFromIndex(table, record, key);
        Field f = ClassDescriptor.locateField(table, key);
        if (f == null) { 
            throw new StorageError(StorageError.INDEXED_FIELD_NOT_FOUND, table.getName());
        } 
        try { 
            f.set(record, value);
        } catch (Exception x) { 
            throw new StorageError(StorageError.ACCESS_VIOLATION, x);
        }
        storage.modify(record);
        includeInIndex(table, record, key);
    }
            


    /**
     * Select record from specified table
     * @param table class corresponding to the table
     * @param predicate search predicate
     * @exception StorageError (CLASS_NOT_FOUND) exception is thrown if there is no table corresponding to 
     * the specified class
     * @return iterator through selected records. This iterator doesn't support remove() method
     * @exception CompileError exception is thrown if predicate is not valid JSQL exception
     * @exception JSQLRuntimeException exception is thrown if there is runtime error during query execution
     */
    public <T> IterableIterator<T> select(Class table, String predicate) { 
        return select(table, predicate, false);
    }

    /**
     * Select record from specified table
     * @param table class corresponding to the table
     * @param predicate search predicate
     * @param forUpdate <code>true</code> if records are selected for update - in this case exclusive lock is set 
     * for the table to avoid deadlock.
     * @exception StorageError (CLASS_NOT_FOUND) exception is thrown if there is no table corresponding to 
     * the specified class
     * @return iterator through selected records. This iterator doesn't support remove() method
     * @exception CompileError exception is thrown if predicate is not valid JSQL exception
     * @exception JSQLRuntimeException exception is thrown if there is runtime error during query execution
     */
    @SuppressWarnings("unchecked")
    public <T> IterableIterator<T> select(Class table, String predicate, boolean forUpdate) { 
        Query q = prepare(table, predicate, forUpdate);
        return q.execute(getRecords(table));
    }

    /**
     * Prepare JSQL query. Prepare is needed for queries with parameters. Also
     * preparing query can improve speed if query will be executed multiple times
     * (using prepare, it is compiled only once).<P>
     * To execute prepared query, you should use Query.execute(db.getRecords(XYZ.class)) method
     * @param table class corresponding to the table
     * @param predicate search predicate
     * @exception StorageError (CLASS_NOT_FOUND) exception is thrown if there is no table corresponding to 
     * the specified class
     * @exception CompileError exception is thrown if predicate is not valid JSQL exception
     * @return prepared query
     */
    public <T> Query<T> prepare(Class table, String predicate) { 
        return prepare(table, predicate, false);
    }

    /**
     * Prepare JSQL query. Prepare is needed for queries with parameters. Also
     * preparing query can improve speed if query will be executed multiple times
     * (using prepare, it is compiled only once).<P>
     * To execute prepared query, you should use Query.execute() or 
     * Query.execute(db.getRecords(XYZ.class)) method
     * @param table class corresponding to the table
     * @param predicate search predicate
     * @param forUpdate <code>true</code> if records are selected for update - in this case exclusive lock is set 
     * for the table to avoid deadlock.
     * @exception StorageError (CLASS_NOT_FOUND) exception is thrown if there is no table corresponding to 
     * the specified class
     * @exception CompileError exception is thrown if predicate is not valid JSQL exception
     * @return prepared query
     */
    public <T> Query<T> prepare(Class table, String predicate, boolean forUpdate) { 
        Query<T> q = createQuery(table, forUpdate);
        q.prepare(table, predicate);      
        return q;
    }
        
    /**
     * Create query for the specified class. You can use Query.getCodeGenerator method to generate 
     * query code.
     * @param table class corresponding to the table
     * @exception StorageError (CLASS_NOT_FOUND) exception is thrown if there is no table corresponding to 
     * the specified class
     * @return query without predicate
     */
    public <T> Query<T> createQuery(Class table)
    {
        return createQuery(table, false);
    }

    /**
     * Create query for the specified class. You can use Query.getCodeGenerator method to generate 
     * query code.
     * @param table class corresponding to the table
     * @param forUpdate <code>true</code> if records are selected for update - in this case exclusive lock is set 
     * for the table to avoid deadlock.
     * @exception StorageError (CLASS_NOT_FOUND) exception is thrown if there is no table corresponding to 
     * the specified class
     * @return query without predicate
     */
    @SuppressWarnings("unchecked")
    public <T> Query<T> createQuery(Class table, boolean forUpdate) { 
        Table t = locateTable(table, forUpdate, false);
        Query q = storage.createQuery();
        q.setIndexProvider(this);
        q.setClass(table);
        while (t != null) { 
            q.setClassExtent(t.extent, multithreaded ? forUpdate ? Query.ClassExtentLockType.Exclusive : Query.ClassExtentLockType.Shared : Query.ClassExtentLockType.None);
            Iterator iterator = t.indicesMap.entrySet().iterator();
            while (iterator.hasNext()) { 
                Map.Entry entry = (Map.Entry)iterator.next();
                FieldIndex index = (FieldIndex)entry.getValue();
                String key = (String)entry.getKey();
                q.addIndex(key, index);
            }
            t = locateTable(t.type.getSuperclass(), forUpdate, false);
        }
        return q;
    }

    /** 
     * Get iterator through all table records
     * @param table class corresponding to the table
     * @return iterator through all table records.
     * @exception StorageError (CLASS_NOT_FOUND) exception is thrown if there is no table corresponding to 
     * the specified class
     */
    public <T> IterableIterator<T> getRecords(Class table) { 
        return getRecords(table, false);
    }

    /** 
     * Get iterator through all table records
     * @param table class corresponding to the table
     * @param forUpdate <code>true</code> if records are selected for update - in this case exclusive lock is set 
     * for the table to avoid deadlock.
     * @return iterator through all table records.
     * @exception StorageError (CLASS_NOT_FOUND) exception is thrown if there is no table corresponding to 
     * the specified class
     */

    @SuppressWarnings("unchecked")
    public <T> IterableIterator<T> getRecords(Class table, boolean forUpdate) { 
        Table t = locateTable(table, forUpdate, false);
        return new IteratorWrapper<T>(t == null ? new LinkedList<T>().iterator() : new ClassFilterIterator(table, t.extent.iterator()));
    }

    /**
     * Get number of records in the table
     * @param table class corresponding to the table
     * @return number of records in the table associated with specified class
     */
    public int countRecords(Class table) {
        return countRecords(table, false);
    }

    /**
     * Get number of records in the table 
     * @param table class corresponding to the table
     * @param forUpdate <code>true</code> if you are going to update the table - in this case exclusive lock is set 
     * for the table to avoid deadlock.
     * @return number of records in the table associated with specified class
     */
    public int countRecords(Class table, boolean forUpdate) { 
        Table t = locateTable(table, forUpdate, false);
        return t == null ? 0 : t.extent.size();        
    }

    /**
     * Get storage associated with this database
     * @return underlying storage
     */
    public Storage getStorage() { 
        return storage;
    }

    /**
     * Get full text index
     * @return used full text index
     */
    public FullTextIndex getFullTextIndex() { 
        return metadata.fullTextIndex;
    }

    /**
     * Locate all documents containing words started with specified prefix
     * @param prefix word prefix
     * @param maxResults maximal amount of selected documents
     * @param timeLimit limit for query execution time
     * @param sort whether it is necessary to sort result by rank
     * @return result of query execution ordered by rank (of sort==true) or null in case of empty or incorrect query  
     */
    public FullTextSearchResult searchPrefix(String prefix, int maxResults, int timeLimit, boolean sort) {
        if (multithreaded) { 
            checkTransaction();
            metadata.fullTextIndex.sharedLock();
        }
        return metadata.fullTextIndex.searchPrefix(prefix, maxResults, timeLimit, sort);
    }

    /**
     * Parse and execute full text search query
     * @param query text of the query
     * @param language language if the query
     * @param maxResults maximal amount of selected documents
     * @param timeLimit limit for query execution time
     * @return result of query execution ordered by rank or null in case of empty or incorrect query
     */
    public FullTextSearchResult search(String query, String language, int maxResults, int timeLimit) {
        if (multithreaded) { 
            checkTransaction();
            metadata.fullTextIndex.sharedLock();
        }
        return metadata.fullTextIndex.search(query, language, maxResults, timeLimit);
    }

    /**
     * Get iterator through full text index keywords started with specified prefix
     * @param prefix keyword prefix (user empty string to get list of all keywords)
     * @return iterator through list of all keywords with specified prefix
     */
    public Iterator<FullTextIndex.Keyword> getKeywords(String prefix) {
        if (multithreaded) { 
            checkTransaction();
            metadata.fullTextIndex.sharedLock();
        }
        return metadata.fullTextIndex.getKeywords(prefix);
    }

    /**
     * Execute full text search query
     * @param query prepared query
     * @param maxResults maximal amount of selected documents
     * @param timeLimit limit for query execution time
     * @return result of query execution ordered by rank or null in case of empty or incorrect query
     */    
    public FullTextSearchResult search(FullTextQuery query, int maxResults, int timeLimit) {
        if (multithreaded) { 
            checkTransaction();
            metadata.fullTextIndex.sharedLock();
        }
        return metadata.fullTextIndex.search(query, maxResults, timeLimit);
    }


    static class Metadata extends PersistentResource {
        private static final long serialVersionUID = 1L;

        Index<Table> metaclasses;
        FullTextIndex fullTextIndex;

        @SuppressWarnings("unchecked")
        public Metadata(Storage storage, Index index, FullTextSearchHelper helper) { 
            super(storage);
            metaclasses = index;
            fullTextIndex = (helper != null) 
                ? storage.createFullTextIndex(helper)
                : storage.createFullTextIndex();
        }

        @SuppressWarnings("unchecked")
        public Metadata(Storage storage, FullTextSearchHelper helper) { 
            super(storage);
            metaclasses = storage.createIndex(String.class, true);
            fullTextIndex = (helper != null) 
                ? storage.createFullTextIndex(helper)
                : storage.createFullTextIndex();
        }

        public Metadata() {}
    }
        
    static class Table extends Persistent { 
        private static final long serialVersionUID = 1L;

        public Table() {}

        IPersistentSet extent;
        Link           indices;

        transient HashMap<String, FieldIndex> indicesMap = new HashMap<String, FieldIndex>();
        transient ArrayList<Field> fullTextIndexableFields;
        transient Class type;
        transient FieldIndex autoincrementIndex;

        void setClass(Class cls) {
            type = cls;
            fullTextIndexableFields = new ArrayList<Field>();
            for (Field f : cls.getDeclaredFields()) { 
                FullTextIndexable idx = (FullTextIndexable)f.getAnnotation(FullTextIndexable.class);
                if (idx != null) { 
                    try { 
                        f.setAccessible(true);
                    } catch (Exception x) {}
                    fullTextIndexableFields.add(f);
                }            
            }
        } 

        public void onLoad() { 
            for (int i = indices.size(); --i >= 0;) { 
                FieldIndex index = (FieldIndex)indices.get(i);
                Field key = index.getKeyFields()[0];
                indicesMap.put(key.getName(), index);
                Indexable idx = (Indexable)key.getAnnotation(Indexable.class);
                if (idx != null && idx.autoincrement()) { 
                    autoincrementIndex = index;
                }                    
            }            
        }

        public void deallocate() {
            extent.deallocate();
            for (Object index : indicesMap.values()) { 
                ((FieldIndex)index).deallocate();
            }
            super.deallocate();
        }
    }                        

    HashMap<Class,Table> tables;
    Storage  storage;
    Metadata metadata;
    boolean  multithreaded;
    boolean  autoRegisterTables;
    boolean  autoIndices;
    boolean  globalClassExtent;
    boolean  searchBaseClasses;
}

class ClassFilterIterator<T> implements Iterator<T>
{
    public boolean hasNext() {
        return obj != null;
    }

    @SuppressWarnings("unchecked")
    public T next() {
        T curr = (T) obj;
        if (curr == null) { 
           throw new NoSuchElementException();
        }        
        moveNext();
        return curr;
    }

    public ClassFilterIterator(Class<T> c, Iterator<?> i) {
        cls = c;
        iterator = i;
        moveNext();
   }
        
    public void remove() {
        throw new UnsupportedOperationException();
    }

    private void moveNext() {
        obj = null;
        while (iterator.hasNext()) { 
            Object curr = iterator.next();
            if (cls.isInstance(curr)) { 
                obj = curr;
                return;
            }
        }
    }

    private Iterator<?> iterator;
    private Class<T> cls;
    private Object obj;
}
   
