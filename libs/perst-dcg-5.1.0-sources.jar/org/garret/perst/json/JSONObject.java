package org.garret.perst.json;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Minimal JSON object implementation for Perst serialization.
 * Only includes operations needed for entity serialization.
 * 
 * Design: ~200 lines, zero external dependencies.
 * "Simple and elegant always prevails."
 */
public class JSONObject implements Iterable<String> {
    
    /**
     * Null value sentinel for JSON.
     */
    public static final Object NULL = new Object() {
        @Override
        public String toString() {
            return "null";
        }
    };
    
    private final Map<String, Object> map;
    
    public JSONObject() {
        this.map = new LinkedHashMap<>();
    }
    
    /**
     * Put key-value pair into the object.
     * @return this object for chaining
     */
    public JSONObject put(String key, Object value) {
        if (key == null) {
            throw new JSONException("Key cannot be null");
        }
        if (value == null) {
            map.put(key, NULL);
        } else {
            map.put(key, value);
        }
        return this;
    }
    
    /**
     * Get value by key.
     */
    public Object get(String key) {
        Object value = opt(key);
        if (value == null) {
            throw new JSONException("Key not found: " + key);
        }
        return value;
    }
    
    /**
     * Get value by key, returning fallback if not found.
     */
    public Object opt(String key, Object fallback) {
        Object value = map.get(key);
        if (value == null || value == NULL) {
            return fallback;
        }
        return value;
    }
    
    /**
     * Get value by key, returning null if not found.
     */
    public Object opt(String key) {
        return opt(key, null);
    }
    
    /**
     * Get string value by key.
     */
    public String getString(String key) {
        Object value = get(key);
        return value.toString();
    }
    
    /**
     * Get string value with default.
     */
    public String getString(String key, String defaultValue) {
        Object value = opt(key);
        if (value == null) {
            return defaultValue;
        }
        return value.toString();
    }
    
    /**
     * Get int value by key.
     */
    public int getInt(String key) {
        Object value = get(key);
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        return Integer.parseInt(value.toString());
    }
    
    /**
     * Get int value with default.
     */
    public int getInt(String key, int defaultValue) {
        Object value = opt(key);
        if (value == null) {
            return defaultValue;
        }
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        return Integer.parseInt(value.toString());
    }
    
    /**
     * Get long value by key.
     */
    public long getLong(String key) {
        Object value = get(key);
        if (value instanceof Number) {
            return ((Number) value).longValue();
        }
        return Long.parseLong(value.toString());
    }
    
    /**
     * Get long value with default.
     */
    public long getLong(String key, long defaultValue) {
        Object value = opt(key);
        if (value == null) {
            return defaultValue;
        }
        if (value instanceof Number) {
            return ((Number) value).longValue();
        }
        return Long.parseLong(value.toString());
    }
    
    /**
     * Get double value by key.
     */
    public double getDouble(String key) {
        Object value = get(key);
        if (value instanceof Number) {
            return ((Number) value).doubleValue();
        }
        return Double.parseDouble(value.toString());
    }
    
    /**
     * Get double value with default.
     */
    public double getDouble(String key, double defaultValue) {
        Object value = opt(key);
        if (value == null) {
            return defaultValue;
        }
        if (value instanceof Number) {
            return ((Number) value).doubleValue();
        }
        return Double.parseDouble(value.toString());
    }
    
    /**
     * Get boolean value by key.
     */
    public boolean getBoolean(String key) {
        Object value = get(key);
        if (value instanceof Boolean) {
            return (Boolean) value;
        }
        return Boolean.parseBoolean(value.toString());
    }
    
    /**
     * Get boolean value with default.
     */
    public boolean getBoolean(String key, boolean defaultValue) {
        Object value = opt(key);
        if (value == null) {
            return defaultValue;
        }
        if (value instanceof Boolean) {
            return (Boolean) value;
        }
        return Boolean.parseBoolean(value.toString());
    }
    
    /**
     * Get JSONObject value by key.
     */
    public JSONObject getJSONObject(String key) {
        Object value = get(key);
        if (value instanceof JSONObject) {
            return (JSONObject) value;
        }
        throw new JSONException("Not a JSONObject: " + key);
    }
    
    /**
     * Get JSONArray value by key.
     */
    public JSONArray getJSONArray(String key) {
        Object value = get(key);
        if (value instanceof JSONArray) {
            return (JSONArray) value;
        }
        throw new JSONException("Not a JSONArray: " + key);
    }
    
    /**
     * Check if key exists.
     */
    public boolean has(String key) {
        return map.containsKey(key);
    }
    
    /**
     * Remove key from object.
     */
    public Object remove(String key) {
        return map.remove(key);
    }
    
    /**
     * Get all keys.
     */
    public JSONArray keys() {
        JSONArray array = new JSONArray();
        for (String key : map.keySet()) {
            array.put(key);
        }
        return array;
    }
    
    /**
     * Number of key-value pairs.
     */
    public int length() {
        return map.size();
    }
    
    /**
     * Check if object is empty.
     */
    public boolean isEmpty() {
        return map.isEmpty();
    }
    
    @Override
    public Iterator<String> iterator() {
        return map.keySet().iterator();
    }
    
    /**
     * Convert to JSON string.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append('{');
        boolean first = true;
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            if (!first) {
                sb.append(',');
            }
            first = false;
            sb.append(JSONArray.quote(entry.getKey()));
            sb.append(':');
            sb.append(valueToString(entry.getValue()));
        }
        sb.append('}');
        return sb.toString();
    }
    
    /**
     * Convert value to JSON string representation.
     */
    static String valueToString(Object value) {
        if (value == null || value == NULL) {
            return "null";
        }
        if (value instanceof String) {
            return JSONArray.quote((String) value);
        }
        if (value instanceof Number) {
            return value.toString();
        }
        if (value instanceof Boolean) {
            return value.toString();
        }
        if (value instanceof JSONObject) {
            return value.toString();
        }
        if (value instanceof JSONArray) {
            return value.toString();
        }
        // Fallback: quote as string
        return JSONArray.quote(value.toString());
    }
}
