package org.garret.perst.json;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Minimal JSON array implementation for Perst serialization.
 * Only includes operations needed for entity serialization.
 */
public class JSONArray implements Iterable<Object> {
    
    private final List<Object> list;
    
    public JSONArray() {
        this.list = new ArrayList<>();
    }
    
    public JSONArray(Iterable<?> iterable) {
        this.list = new ArrayList<>();
        for (Object item : iterable) {
            list.add(item);
        }
    }
    
    /**
     * Append value to the array.
     * @return this array for chaining
     */
    public JSONArray put(Object value) {
        list.add(value);
        return this;
    }
    
    /**
     * Put value at specific index.
     * @return this array for chaining
     */
    public JSONArray put(int index, Object value) {
        list.add(index, value);
        return this;
    }
    
    /**
     * Get value at index.
     */
    public Object get(int index) {
        Object value = opt(index);
        if (value == null) {
            throw new JSONException("Index " + index + " out of range");
        }
        return value;
    }
    
    /**
     * Get value at index, returning fallback if not found.
     */
    public Object opt(int index) {
        if (index < 0 || index >= list.size()) {
            return null;
        }
        Object value = list.get(index);
        if (value == null || value == JSONObject.NULL) {
            return null;
        }
        return value;
    }
    
    /**
     * Get string at index.
     */
    public String getString(int index) {
        Object value = get(index);
        return value.toString();
    }
    
    /**
     * Get int at index.
     */
    public int getInt(int index) {
        Object value = get(index);
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        return Integer.parseInt(value.toString());
    }
    
    /**
     * Get long at index.
     */
    public long getLong(int index) {
        Object value = get(index);
        if (value instanceof Number) {
            return ((Number) value).longValue();
        }
        return Long.parseLong(value.toString());
    }
    
    /**
     * Get double at index.
     */
    public double getDouble(int index) {
        Object value = get(index);
        if (value instanceof Number) {
            return ((Number) value).doubleValue();
        }
        return Double.parseDouble(value.toString());
    }
    
    /**
     * Get boolean at index.
     */
    public boolean getBoolean(int index) {
        Object value = get(index);
        if (value instanceof Boolean) {
            return (Boolean) value;
        }
        return Boolean.parseBoolean(value.toString());
    }
    
    /**
     * Get JSONObject at index.
     */
    public JSONObject getJSONObject(int index) {
        Object value = get(index);
        if (value instanceof JSONObject) {
            return (JSONObject) value;
        }
        throw new JSONException("Not a JSONObject at index " + index);
    }
    
    /**
     * Get JSONArray at index.
     */
    public JSONArray getJSONArray(int index) {
        Object value = get(index);
        if (value instanceof JSONArray) {
            return (JSONArray) value;
        }
        throw new JSONException("Not a JSONArray at index " + index);
    }
    
    /**
     * Number of elements in the array.
     */
    public int length() {
        return list.size();
    }
    
    /**
     * Check if array is empty.
     */
    public boolean isEmpty() {
        return list.isEmpty();
    }
    
    /**
     * Remove element at index.
     */
    public Object remove(int index) {
        if (index < 0 || index >= list.size()) {
            return null;
        }
        return list.remove(index);
    }
    
    @Override
    public Iterator<Object> iterator() {
        return list.iterator();
    }
    
    /**
     * Convert to JSON string.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append('[');
        for (int i = 0; i < list.size(); i++) {
            if (i > 0) {
                sb.append(',');
            }
            sb.append(valueToString(list.get(i)));
        }
        sb.append(']');
        return sb.toString();
    }
    
    /**
     * Convert value to JSON string representation.
     */
    static String valueToString(Object value) {
        if (value == null || value == JSONObject.NULL) {
            return "null";
        }
        if (value instanceof String) {
            return quote((String) value);
        }
        if (value instanceof Number) {
            return value.toString();
        }
        if (value instanceof Boolean) {
            return value.toString();
        }
        if (value instanceof JSONObject) {
            return value.toString();
        }
        if (value instanceof JSONArray) {
            return value.toString();
        }
        // Fallback: quote as string
        return quote(value.toString());
    }
    
    /**
     * Quote a string for JSON output.
     */
    static String quote(String string) {
        if (string == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        sb.append('"');
        for (int i = 0; i < string.length(); i++) {
            char c = string.charAt(i);
            switch (c) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\b': sb.append("\\b"); break;
                case '\f': sb.append("\\f"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                default:
                    if (c < ' ') {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
            }
        }
        sb.append('"');
        return sb.toString();
    }
}
