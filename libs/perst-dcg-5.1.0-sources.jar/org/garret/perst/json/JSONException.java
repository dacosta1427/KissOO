package org.garret.perst.json;

/**
 * Exception thrown when JSON operations fail.
 * Minimal implementation for Perst JSON serialization.
 */
public class JSONException extends RuntimeException {
    
    public JSONException(String message) {
        super(message);
    }
    
    public JSONException(String message, Throwable cause) {
        super(message, cause);
    }
}
